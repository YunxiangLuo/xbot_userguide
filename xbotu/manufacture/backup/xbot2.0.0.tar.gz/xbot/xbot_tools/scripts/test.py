#coding=utf-8

import ngender
r = ngender.guess('汪鹏')
print r


