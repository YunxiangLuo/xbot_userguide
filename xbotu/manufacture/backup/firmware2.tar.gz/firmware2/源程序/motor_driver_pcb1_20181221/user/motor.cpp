#include "motor.h"
#include "time.h"
#include "hal.h"


Motor1	motor_1;
Motor2	motor_2;
QRobotControl::QRobotControl() :
		hall(0),hall_pre(0),target(0), angle_now(0),angle_now_tmp(0),angle_pre(0), angle_error(0), angle_error_pre(
				0), angle_delta(0), stop_cnt(0){
	pidsum.p = 0;
	pidsum.i = 0;
	pidsum.d = 0;
	pid.p = 0.4;
	pid.i = 0.7;
	pid.d = 0;
	
	pidsum1.p = 0;
	pidsum1.i = 0;
	pidsum1.d = 0;
	pid1.p = 0.535;//0.0135;
	pid1.i = 0.0;
	pid1.d = 0.017;//0.0017;
	
	pidsum2.p = 0;
	pidsum2.i = 0;
	pidsum2.d = 0;
	pid2.p = 1.225;
	pid2.i = 0.89;
	pid2.d = 0.0;
	
	pidsum3.p = 0;
	pidsum3.i = 0;
	pidsum3.d = 0;
	pid3.p = 2.535;//0.0135;
	pid3.i = 0.0;
	pid3.d = 0.017;//0.0017;
	
	pidsum4.p = 0;
	pidsum4.i = 0;
	pidsum4.d = 0;
	pid4.p = 1.425;
	pid4.i = 1.29;
	pid4.d = 0.0;	
	
	
    controllaw = 0;
	max_controllaw=1500;
	max_isum=1500;
}
QRobotControl::~QRobotControl() {
	;
}

Motor1::Motor1() {
	pid.p = 0.60;
	pid.i = 0.90;
	pid.d = 0;
	
	pid2.p = 0.3;
	pid2.i = 0.6;
	pid2.d = 0.0;
}
Motor1::~Motor1() {
	;
}
Motor2::Motor2() {
	pid.p = 0.6;
	pid.i = 0.9;
	pid.d = 0;
	
	pid2.p = 0.4;
	pid2.i = 0.7;
	pid2.d = 0.0;
}
Motor2::~Motor2() {
	;
}

  
void QRobotControl::Speed_control() {
  
  	angle_delta = angle_now - angle_pre;
	scale_adjust(&angle_delta);
	angle_error =target  - angle_delta;	
	angle_pre= angle_now; 
	if(target==0)
	{
	  controllaw=0;  
	  pidsum.i=0;
	  angle_error_pre=0;
	}
		
	if(ABS(angle_delta)<10 && target == 0)
	{
	  stop_cnt++;
	  if(stop_cnt>=2)
		{	
		    angle_error=0;
                    angle_error_pre=0;
                    stop_cnt=2;
                    pidsum.i=0;
	  	}
	}
	else stop_cnt=0;
	if(ABS(angle_delta)==0)//START Action
	  {
//            stop_cnt1++;
//            if(stop_cnt1>2)
//            {
//              stop_cnt1=3;
		state=STOP;	
//            }
	  }
	else 
        {
//          stop_cnt1=0;
          state=RUN;
        }
	
	if(angle_error>100)// limit Acceleration
	  angle_error=100;
	if(angle_error<-100)
	  angle_error=-100;

	pidsum.p = pid.p * angle_error;
	pidsum.i += pid.i * angle_error * dt;
	restrict_params(&pidsum.i, max_isum);
	pidsum.d = pid.d * (angle_error - angle_error_pre) / dt;

	
    ControlLaw_Pre = -(int)(pidsum.p + pidsum.i + pidsum.d);	
    if(ControlLaw_Pre>1500)
      ControlLaw_Pre=1500;
    if(ControlLaw_Pre<-1500)
      ControlLaw_Pre=-1500;
//      restrict_params(&ControlLaw_Pre, max_controllaw);
	if(ABS(ControlLaw_Pre)>50)	  
		controllaw = ControlLaw_Pre;
	else if(target!=0)
	  controllaw=ControlLaw_Pre>0?  (ControlLaw_Pre+50):(ControlLaw_Pre-50);
  
    angle_error_pre = angle_error;
}


/**************************************************************
*  MOTOR 1  
**************************************************************/
void Motor1::read_hall_state(){
	hall = GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_6)//A --U
			| GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_5) << 1//B--V
			| GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_7) << 2;//C--W
}

void Motor1::judge_hall() {
    read_hall_state();
    if (hall!= hall_pre) {
        hall_pre = hall;        
    }
    act_controllaw();
}
void Motor1::act_controllaw(){
//  controllaw=100;
  if(controllaw>0){
      switch (hall) {
	    case 6:
		U1_H_PWM = controllaw;  
		V1_H_PWM = 0;   
		W1_H_PWM = 0;
		U1_L_OFF;	
		V1_L_ON;
		W1_L_OFF;
		break;
	    case 2:	
		U1_H_PWM = controllaw;  
		V1_H_PWM = 0;   
		W1_H_PWM = 0;
		U1_L_OFF;	
		V1_L_OFF;
		W1_L_ON;
		break;
	    case 3:
		U1_H_PWM = 0;  
		V1_H_PWM = controllaw;   
		W1_H_PWM = 0;
		U1_L_OFF;	
		V1_L_OFF;
		W1_L_ON;
		break;
	    case 1:
		U1_H_PWM = 0;  
		V1_H_PWM = controllaw;    
		W1_H_PWM = 0;  
		U1_L_ON;   
		V1_L_OFF;
		W1_L_OFF;
		break;
	    case 5:
		U1_H_PWM = 0; 
		V1_H_PWM = 0;  
		W1_H_PWM = controllaw; 
		U1_L_ON; 		
		V1_L_OFF;		
		W1_L_OFF;		   
		break;
	    case 4:
		U1_H_PWM = 0;   
		V1_H_PWM = 0;
		W1_H_PWM = controllaw; 
		U1_L_OFF;		
		V1_L_ON;		
		W1_L_OFF;		
		break;
	    default:
               U1_H_PWM = 0;   
               V1_H_PWM = 0;
               W1_H_PWM = 0; 
               U1_L_OFF;
               V1_L_OFF;
               W1_L_OFF;
		break;
      }
  }
  else if(controllaw<0){
		hall=7-hall;
          switch (hall) {
	    case 6:
		U1_H_PWM = -controllaw;  
		V1_H_PWM = 0;   
		W1_H_PWM = 0;
		U1_L_OFF;	
		V1_L_ON;
		W1_L_OFF;
		break;
	    case 2:	
		U1_H_PWM = -controllaw;  
		V1_H_PWM = 0;   
		W1_H_PWM = 0;
		U1_L_OFF;	
		V1_L_OFF;
		W1_L_ON;
		break;
	    case 3:
		U1_H_PWM = 0;  
		V1_H_PWM = -controllaw;   
		W1_H_PWM = 0;
		U1_L_OFF;	
		V1_L_OFF;
		W1_L_ON;
		break;
	    case 1:
		U1_H_PWM = 0;  
		V1_H_PWM = -controllaw;    
		W1_H_PWM = 0;  
		U1_L_ON;   
		V1_L_OFF;
		W1_L_OFF;
		break;
	    case 5:
		U1_H_PWM = 0; 
		V1_H_PWM = 0;  
		W1_H_PWM = -controllaw; 
		U1_L_ON; 		
		V1_L_OFF;		
		W1_L_OFF;		   
		break;
	    case 4:
		U1_H_PWM = 0;   
		V1_H_PWM = 0;
		W1_H_PWM = -controllaw; 
		U1_L_OFF;		
		V1_L_ON;		
		W1_L_OFF;		
		break;
	    default:
	      U1_L_OFF;
		  V1_L_OFF;
		  W1_L_OFF;
		break;
      }
  }
      else
      {
          U1_H_PWM = 0;   
          V1_H_PWM = 0;
          W1_H_PWM = 0;        
          U1_L_OFF;
          V1_L_OFF;
          W1_L_OFF;
      }
}
/**************************************************************
*  MOTOR 2  
**************************************************************/
void Motor2::read_hall_state(){
	hall = GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_1)           //A-U
			| GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_0) << 1   //B--V
			| GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_2) << 2;  //C--W
}

void Motor2::judge_hall() {
    read_hall_state();
    if (hall != hall_pre) {
        hall_pre = hall;        
    }
    act_controllaw();
}
void Motor2::act_controllaw(){
//  controllaw=400;
  if(controllaw>0){
      switch (hall) {
	    case 6:
		U2_H_PWM = controllaw;  
		V2_H_PWM = 0;   
		W2_H_PWM = 0;
		U2_L_OFF;	
		V2_L_ON;
		W2_L_OFF;
		break;
	    case 2:	
		U2_H_PWM = controllaw;  
		V2_H_PWM = 0;   
		W2_H_PWM = 0;
		U2_L_OFF;	
		V2_L_OFF;
		W2_L_ON;
		break;
	    case 3:
		U2_H_PWM = 0;  
		V2_H_PWM = controllaw;   
		W2_H_PWM = 0;
		U2_L_OFF;	
		V2_L_OFF;
		W2_L_ON;
		break;
	    case 1:
		U2_H_PWM = 0;  
		V2_H_PWM = controllaw;    
		W2_H_PWM = 0;  
		U2_L_ON;   
		V2_L_OFF;
		W2_L_OFF;
		break;
	    case 5:
		U2_H_PWM = 0; 
		V2_H_PWM = 0;  
		W2_H_PWM = controllaw; 
		U2_L_ON; 		
		V2_L_OFF;		
		W2_L_OFF;		   
		break;
	    case 4:
		U2_H_PWM = 0;   
		V2_H_PWM = 0;
		W2_H_PWM = controllaw; 
		U2_L_OFF;		
		V2_L_ON;		
		W2_L_OFF;		
		break;
	    default:
               U2_H_PWM = 0;   
               V2_H_PWM = 0;
               W2_H_PWM = 0;             
               U2_L_OFF;
               V2_L_OFF;
               W2_L_OFF;
		break;
      }
  }
  else if(controllaw<0){
    hall=7-hall;
    switch (hall) {
	    case 6:								
		U2_H_PWM = -controllaw; 		
		V2_H_PWM = 0;		
		W2_H_PWM = 0;		
		U2_L_OFF;
		V2_L_ON;
		W2_L_OFF;
		break;
	    case 2:			
		U2_H_PWM = -controllaw; 
		V2_H_PWM = 0;
		W2_H_PWM = 0;
		U2_L_OFF;  
		V2_L_OFF;		
		W2_L_ON;		
		break;
	    case 3:		
		U2_H_PWM = 0; 		
		V2_H_PWM = -controllaw; 		
		W2_H_PWM = 0;
		U2_L_OFF;
		V2_L_OFF;
		W2_L_ON;   
		break;
	    case 1:		
		U2_H_PWM = 0;  
		V2_H_PWM = -controllaw;  
		W2_H_PWM = 0;
		U2_L_ON;   
		V2_L_OFF;		
		W2_L_OFF;		
		break;
	    case 5:		
		U2_H_PWM = 0; 
		V2_H_PWM = 0;
		W2_H_PWM = -controllaw;
		U2_L_ON;  
		V2_L_OFF;		
		W2_L_OFF;
		break;
	    case 4:		
		U2_H_PWM = 0;   
		V2_H_PWM = 0;
		W2_H_PWM = -controllaw;
		U2_L_OFF;
		V2_L_ON;		
		W2_L_OFF;  		
		break;
	    default:
	      U2_L_OFF;
	      V2_L_OFF;
	      W2_L_OFF;
	      break;
      }
  }
    else
    {
               U2_H_PWM = 0;   
               V2_H_PWM = 0;
               W2_H_PWM = 0;             
               U2_L_OFF;
               V2_L_OFF;
               W2_L_OFF;
   
    }
}

void QRobotControl::restrict_params(float* para, float Threshold){
	if(*para>Threshold)*para=Threshold;
	if(*para<-Threshold)*para=-Threshold;
}
void QRobotControl::restrict_params(int* para, int Threshold){
	if(*para>Threshold)*para=Threshold;
	if(*para<-Threshold)*para=-Threshold;
}
void QRobotControl::scale_adjust(s16* data){
	if(*data>half_cycle)
		*data = *data - ENCODER_FULL;
	if(*data<-half_cycle)
		*data = *data + ENCODER_FULL;
}