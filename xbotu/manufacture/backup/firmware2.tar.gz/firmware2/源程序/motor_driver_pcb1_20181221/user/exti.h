#ifndef __EXTI_H__
#define __EXTI_H__
#include "stm32f10x_exti.h" 
#include "stm32f10x.h"

//extern LMOTORA	lmotora;
//extern LMOTORB	lmotorb;
//extern LMOTORC	lmotorc;
//extern RMOTORA	rmotora;
//extern RMOTORB	rmotorb;
//extern RMOTORC	rmotorc;
#endif
