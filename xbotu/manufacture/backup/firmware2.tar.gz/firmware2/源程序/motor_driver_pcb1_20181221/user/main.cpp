/************************************************************
**实验名称:baofeng
**功能:motor driver
**注意事项:
**作者:BOBO
*************************************************************/
#include <string.h>
#include "hal.h"	

/*************test**************/
#include "stdio.h"
#include "stm32f10x_usart.h"
/*************test**************/

#define CTRL_FREQ 50
#define CMD_LOST_MS 500

#define TOP_BOTTOM  29000.0

#define STEER_CYCLE  20000

#define CYCLE_CNT  ENCODER_FULL
#define WHEEL_R    0.1//轮子半径
#define CAR_R      0.24//俩轮子之间的距离除以2
#define K1      (CYCLE_CNT/(WHEEL_R*2.0*3.1415926)/CTRL_FREQ)
#define B1 	(CYCLE_CNT*CAR_R/(360*CTRL_FREQ*WHEEL_R))
#define K2      (ENCODER_FULL/(WHEEL_R*2*3.1415926))//全向轮45度分线速度
#define B2 		(ENCODER_FULL*CAR_R/(360.0*WHEEL_R))

u8 dma_flag,dma_sense_flag,dma_imu_flag,dma_gps_flag;
u16 time_10us_count=0;
u16 time_1ms_count=0;
u8  time_control_flag,time_50ms_flag,time_50ms_cnt;
u16  cmd_lost_time=0;



Cmd cmd;
Ultra ultra;
short int yall_buf;
float yall,yall_pre,yall_delta,yall_delta_pre;
float x_distance;
float z_distance,z_distance_pre;


MotorPid pid;
MotorPid pidsum;

float x_speed,y_speed,z_speed;


u8 location,start_flag;
u16 bottom_value;

float linerspeed,anglespeed;

u16 steer_cnt,steer_pwm1,steer_pwm2;
u16 trig_cnt=0;

u8 batteryvolate;
u16 chargeivalue;
u8 stopstate;
u16 errorstate;
u16 test;
CaptureTypedef  ult0,ult1,ult2,ult3,ult4,ult5;
extern u16 rx1buf[UART1_RXSIZE];
extern uint32_t micros(void);
void com1Cmd1();//POWER_ON/OFF
void com1Cmd2();//MOTOR_DIS/ENABLE

void ultCapture(void);
void upDownControl(void);
void remoteCapture(void);
float test11;
        u8 kk;
u8 power_state;
float iValue_motor1[9],iValue_motor2[9];
uint16_t battery_test[9];
u8 battery_cnt;
uint16_t battery_test1_mid[4];

uint16_t middle(uint16_t a, uint16_t b, uint16_t c)
{
if(a > b)
     if(a > c)
          if(b > c)
               return b;
          else
               return c;
     else
          return a;
else
if(b > c)
     if(a > c)
          return a;
     else
          return c;
else
     return b;
}
u8 kkk;
int main(void)
{
	u8 ch;	
	
//	pidsum.p = 0;
//	pidsum.i = 0;
//	pidsum.d = 0;
//	pid.p = 0.03;
//	pid.i = 0.06;
//	pid.d = 0;//0.0;
	delayMs(50);
	chipHalInit();			//片内硬件初始化
	chipOutHalInit();		//片外硬件初始化
	delayMs(50);
//	motor_1.target=-10;
//	motor_2.target=-10;

	MOTOR1_ENABLE;
	MOTOR2_ENABLE;
	start_flag=1;
        POWER_ON;
        ASUS_ON;
        delayMs(50);
        delayMs(50);  //NUC power on 100ms
        ASUS_OFF;

	while(1)
	{          
		 ultCapture();	  
		 if( usart1GetByte(&ch) )
                 {	// base Control		 
			if( com1.decodeFrame(ch) ) 
                        {  kk++;
				cmd_lost_time=0;
				ledFlash();
				switch(com1.rx_buf[3])
					{
					case 0x01:com1Cmd1();break;
					case 0x02:com1Cmd2();break;
					default : break;
					}				
			}
		}
		 if( usart2GetByte(&ch) )//battery 0
                 {		 
			if( usart2_com.decodeBatt(ch) ) 
                        {  
				ledFlash();
                                battery1.volate=(usart2_com.rx_buf[4]<<8|usart2_com.rx_buf[5]);
                                battery1.chargeivalue=usart2_com.rx_buf[6]<<8|usart2_com.rx_buf[7];
                                chargeivalue=(battery1.chargeivalue+battery2.chargeivalue)/2;
                                
                                
                                battery1.power_reserve=usart2_com.rx_buf[8]<<8|usart2_com.rx_buf[9];
                                battery1.power_stand=usart2_com.rx_buf[10]<<8|usart2_com.rx_buf[11];  
                                battery1.use_cnt=usart2_com.rx_buf[12]<<8|usart2_com.rx_buf[13]; 
                                  
                                battery1.rsoc=usart2_com.rx_buf[23];                                
                                batteryvolate=(battery1.rsoc+battery2.rsoc)/2;
                                
			}
		}
		 if( usart3GetByte(&ch) )//battery 1
                 {			 
			if( usart3_com.decodeBatt(ch) ) 
                        {  
				ledFlash();
                                battery2.volate=(usart3_com.rx_buf[4]<<8|usart3_com.rx_buf[5]);
				battery2.chargeivalue=(usart3_com.rx_buf[6]<<8|usart3_com.rx_buf[7]);
                                chargeivalue=(battery1.chargeivalue+battery2.chargeivalue)/2;
                                
                                battery2.power_reserve=usart3_com.rx_buf[8]<<8|usart3_com.rx_buf[9];
                                battery2.power_stand=usart3_com.rx_buf[10]<<8|usart3_com.rx_buf[11]; 
                                battery2.use_cnt=usart3_com.rx_buf[12]<<8|usart3_com.rx_buf[13]; 
                                
                                battery2.rsoc=usart3_com.rx_buf[23];                                
                                batteryvolate=(battery1.rsoc+battery2.rsoc)/2;	
                                
			}
		}
                
                
		 if(cmd_lost_time>CMD_LOST_MS )//超过XXms，强制target 清零。指令中断
		 {
			cmd_lost_time=CMD_LOST_MS+1;
			motor_1.target=0;
			motor_2.target=0;
			motor_2.controllaw=0;
			motor_1.controllaw=0;  
			motor_2.pidsum.i=0;
			motor_1.pidsum.i=0;
			motor_2.judge_hall();
			motor_1.judge_hall();
                        anglespeed=0.0;
                        linerspeed=0.0;
		 }
		 if(time_50ms_flag)
		 {
                        if(adc_convertedvalut[8]<670)
                        {
                              ledBattery();
                        }	
			ledFlash();
                        
			memcpy(com1.tx_buf+4,&motor_1.angle_now,2);
			memcpy(com1.tx_buf+6,&motor_2.angle_now_tmp,2);   
//                        
//                        
                        USART_DMA_Enable(DMA1_Channel2, (u32)&usart3_com.tx_buf, 7);//battery 1
                        USART_DMA_Enable(DMA1_Channel7, (u32)&usart2_com.tx_buf, 7);//battery 2                        
                        
		   	memcpy(com1.tx_buf+8,&chargeivalue,2);//充电电流
                        
                        battery_test[battery_cnt++]=adc_convertedvalut[6];
//                        battery_test[battery_cnt++]=kkk++;
                        if(battery_cnt>8)
                          battery_cnt=0;
                        if(battery_cnt==3 || battery_cnt==6 || battery_cnt==0)
                        {
                          battery_test1_mid[0]=middle(battery_test[0],battery_test[1],battery_test[2]);
                          battery_test1_mid[1]=middle(battery_test[3],battery_test[4],battery_test[5]);
                          battery_test1_mid[2]=middle(battery_test[6],battery_test[7],battery_test[8]);
                          
                          battery_test1_mid[3]=(u16)((battery_test1_mid[0]+battery_test1_mid[1]+battery_test1_mid[2])/3.0);  //tanjian modify
                          if (battery_test1_mid[3]<2540)
                              battery_test1_mid[3]=2540;
                          
                          batteryvolate=(3.3*battery_test1_mid[3]/4096*10.1-20.5)/8.7*100;  //tanjian modify
                          if (batteryvolate>100)
                            batteryvolate=100;  //tanjian add
                        
                        }
			memcpy(com1.tx_buf+10,&batteryvolate,1);//电池电量
                        
                        
                        
			memcpy(com1.tx_buf+11,&ult0.ech_data,2);//Front_left超声测距 0~65535/ 1us
                        memcpy(com1.tx_buf+13,&ult1.ech_data,2);//Front_cent超声测距 0~65535/ 1us
                        memcpy(com1.tx_buf+15,&ult2.ech_data,2);//Front_right超声测距 0~65535/ 1us
			memcpy(com1.tx_buf+17,&ult3.ech_data,2);//Back_left超声测距 0~65535/ 1us
                        memcpy(com1.tx_buf+19,&ult4.ech_data,2);//Back_cent超声测距 0~65535/ 1us
                        memcpy(com1.tx_buf+21,&ult5.ech_data,2);//Back_right超声测距 0~65535/ 1us

                        
                        memcpy(com1.tx_buf+23,adc_convertedvalut,2);//Front_left红外
			memcpy(com1.tx_buf+25,adc_convertedvalut+1,2);//Front_cent红外
                        memcpy(com1.tx_buf+27,adc_convertedvalut+2,2);//Front_cent红外
                        memcpy(com1.tx_buf+29,adc_convertedvalut+3,2);//Back_left红外
                        memcpy(com1.tx_buf+31,adc_convertedvalut+4,2);//Back_cent红外
                        memcpy(com1.tx_buf+33,adc_convertedvalut+5,2);//Back_cent红外
//                        
                        stopstate = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0); 
                        if(!stopstate)
                        {
                         motor_1.target=0;
                         motor_2.target=0;
                         motor_2.controllaw=0;
                         motor_1.controllaw=0;  
                         motor_2.pidsum.i=0;
                         motor_1.pidsum.i=0;
                         motor_2.judge_hall();
                         motor_1.judge_hall();
                         anglespeed=0.0;
                         linerspeed=0.0;                          
                         power_state=OFF;
                         BATTERY_OFF;
                        }                          
                        else 
                        {
                          power_state=ON;
                          BATTERY_ON;
                        }
                        memcpy(com1.tx_buf+35,&stopstate,1); //急停开关状态     
                        iValue_motor1[0]=(3.3*adc_convertedvalut[7]/4096+0.4-2.5)*10000;
                        iValue_motor2[0]=(3.3*adc_convertedvalut[8]/4096+0.4-2.5)*10000;
                        
                        iValue_motor1[7]=iValue_motor1[6];
                        iValue_motor1[6]=iValue_motor1[5];
                        iValue_motor1[5]=iValue_motor1[4];
                        iValue_motor1[4]=iValue_motor1[3];
                        iValue_motor1[3]=iValue_motor1[2];
                        iValue_motor1[2]=iValue_motor1[1];
                        iValue_motor1[1]=iValue_motor1[0];
                        iValue_motor1[0]=motor_1.iValue;
                        iValue_motor1[8]=(iValue_motor1[7]+iValue_motor1[6]+iValue_motor1[5]+iValue_motor1[4]+iValue_motor1[3]+iValue_motor1[2]+iValue_motor1[1]+iValue_motor1[0])/8.0;
                        if(iValue_motor1[8]<0)  
                              motor_1.iValue=0;
                        else 
                          motor_1.iValue=iValue_motor1[8];
                        
                        iValue_motor2[7]=iValue_motor2[6];
                        iValue_motor2[6]=iValue_motor2[5];
                        iValue_motor2[5]=iValue_motor2[4];
                        iValue_motor2[4]=iValue_motor2[3];
                        iValue_motor2[3]=iValue_motor2[2];
                        iValue_motor2[2]=iValue_motor2[1];
                        iValue_motor2[1]=iValue_motor2[0];
                        iValue_motor2[0]=motor_1.iValue;
                        iValue_motor2[8]=(iValue_motor2[7]+iValue_motor2[6]+iValue_motor2[5]+iValue_motor2[4]+iValue_motor2[3]+iValue_motor2[2]+iValue_motor2[1]+iValue_motor2[0])/8.0;                        
                        if(iValue_motor2[8]<0)  
                              motor_2.iValue=0;
                        else
                          motor_2.iValue=iValue_motor2[8];
                          
                        
                        memcpy(com1.tx_buf+36,&motor_1.iValue,4);//左轮电机电流 拷贝2个字节，数组里面预留4个字节
                        memcpy(com1.tx_buf+40,&motor_2.iValue,4);//右轮电机电流
                        
                     //   motor1.iValue=(adc_convertedvalut[7]/4096*3.3+0.4-2.5)/0.18;
                     //   motor2.iValue=(adc_convertedvalut[8]/4096*3.3+0.4-2.5)/0.18;
                          
                          
                      //  memcpy(com1.tx_buf+36,&motor1.iValue,4);//左轮电机电流 拷贝2个字节，数组里面预留4个字节
                     //   memcpy(com1.tx_buf+40,&motor2.iValue,4);//右轮电机电流
                        
                        test=micros();   
                        
                        memcpy(com1.tx_buf+44,&test,2);//时间戳   
                        memcpy(com1.tx_buf+46,&errorstate,2);//故障状态
                        			                     
                        com1.tx_buf[44]=test; //time1 1us cnt
                        com1.tx_buf[45]=test>>8;

//                        com1.tx_buf[10]=com1.tx_buf[10]+1;
                        
                        
			com1.data_deal();
			USART_DMA_Enable(DMA1_Channel4, (u32)&com1.tmp_buf, 49);
			time_50ms_flag=0;
		 }
		 if (time_control_flag){					
			switch(cmd)
			{
			case speed_cmd:
			  
			  motor_1.Speed_control();
			  motor_2.Speed_control();
                       if(adc_convertedvalut[7]>=4096 | adc_convertedvalut[8]>=4096)
			{
			  MOTOR1_DISABLE;
			  MOTOR2_DISABLE;
			  motor_1.pidsum.i=0;
			  motor_2.pidsum.i=0;
			}
			else 
			{
			  MOTOR1_ENABLE;
			  MOTOR2_ENABLE;
			}			  
			  break;
			case X_distance_cmd:
			  
			  	yall_delta = yall_pre - yall;
				pidsum.p = pid.p * yall_delta;
				pidsum.i += pid.i * yall_delta * dt;
				pidsum.d = pid.d * (yall_delta - yall_delta_pre) / dt;

				if(pidsum.i>0.5)
				    pidsum.i=0.5;
				if(pidsum.i<-0.5)
				    pidsum.i=-0.5;
				
				z_speed=-(int)(pidsum.p + pidsum.i + pidsum.d);

				if(z_speed>0.05)
				  z_speed=0.05;
				if(z_speed<-0.05)
				  z_speed=-0.05;
				z_speed=0;//暂时不用IMU修正，等到IMU比较准的时候再用z_speed
				
				if(motor_1.location_flag==1)
				{
					motor_1.target=(int)(x_speed*K1 + K1*z_speed);//结合yall偏移量修正速度			
					
					if(ABS(motor_1.location)<=80)
					{
					  motor_1.target=0;
					  motor_1.controllaw=0;
					  motor_1.pidsum2.i =0;
					  motor_1.angle_error=0;
					  motor_1.location_flag=2;
					}
				}
				if(motor_2.location_flag==1)
				{
					motor_2.target=(int)(-x_speed*K1 + B1*z_speed);	
					if(ABS(motor_2.location)<=80)
					{
					  motor_2.target=0;
					  motor_2.controllaw=0;
					  motor_2.pidsum2.i =0;
					  motor_2.angle_error=0;
					  motor_2.location_flag=2;
					}
				}
				if(motor_1.location_flag==2 && motor_2.location_flag==2)//防止检测到两个轮子到达目的地后，由于抖动反复返回应答指令
				  {
					x_speed=0;
					z_speed=0;
					//z_distance = yall-yall_pre;//到目的地后，不进行角度修正，因为IMU不准
					yall_pre = yall;
					cmd=Z_rotation_cmd;
					//USART_DMA_Enable(DMA1_Channel4, (u32)&com1.rx_buf, com1.rx_buf[2] + 4);
					
					pidsum.i=0;
					motor_1.location_flag=1;
					motor_2.location_flag=1;
				  }
			  break;
			case Z_rotation_cmd:
				
				if(motor_1.location_flag==2 && motor_2.location_flag==2)//防止检测到两个轮子到达目的地后，由于抖动反复返回应答指令
				  {
					cmd=speed_cmd;
					USART_DMA_Enable(DMA1_Channel4, (u32)&com1.rx_buf, com1.rx_buf[2] + 4);
				  }
			  break;
			default : cmd=speed_cmd;break;
			}			
			if(motor_1.state==STOP)
			{
				MOTOR1_DISABLE;				
				motor_1.judge_hall();
				MOTOR1_ENABLE;				
			}			
			if(motor_2.state==STOP)
			{
			  MOTOR2_DISABLE;
			  motor_2.judge_hall();
			  MOTOR2_ENABLE;
			}
			time_control_flag=0;
		 }
	}
}

void com1Cmd1()
{
  if(com1.rx_buf[4])
  {
     POWER_ON;  
     power_state=ON;
  }
  else 
  {
     POWER_OFF;   
     power_state=OFF;
  }
}
void com1Cmd2()
{
  if(power_state==ON)
  {
         cmd=speed_cmd;
         memcpy(&linerspeed,com1.rx_buf+4,4);
         memcpy(&anglespeed,com1.rx_buf+8,4);
         if(linerspeed>1.5)
           linerspeed=1.5;
         if(linerspeed<-1.5)
           linerspeed=-1.5;
         
         if(linerspeed<0.01 && linerspeed>0)
             linerspeed=0.01;
         if(linerspeed>-0.01 && linerspeed<0)
             linerspeed=-0.01;
         if(anglespeed>360)
           anglespeed=360;
         if(anglespeed<-360)
           anglespeed=-360;
         
         if(anglespeed<5 && anglespeed>0)
             anglespeed=5;
         if(anglespeed>-5 && anglespeed<0)
             anglespeed=-5;

         
         motor_1.target=(float)(linerspeed*K1-anglespeed*B1);
         motor_2.target=(float)(-linerspeed*K1-anglespeed*B1);
     }
  else
  {
         motor_1.target=0;
         motor_2.target=0;
         motor_2.controllaw=0;
         motor_1.controllaw=0;  
         motor_2.pidsum.i=0;
         motor_1.pidsum.i=0;
         motor_2.judge_hall();
         motor_1.judge_hall();
         anglespeed=0.0;
         linerspeed=0.0;    
  }
}

 u16 TT[8];   
 u32 tt;
 u8 ultraChanSelect;
void ultCapture(void)
{	
	if(trig_cnt>=5000)
        {
	  trig_cnt=0;
          ultraChanSelect++;
          ultraChanSelect=ultraChanSelect%3;
        }
	if(trig_cnt<50) 
	{
          if(ultraChanSelect==ultra1_2)
          {
            GPIO_SetBits(GPIOE,GPIO_Pin_1);
            GPIO_SetBits(GPIOE,GPIO_Pin_0);
            GPIO_ResetBits(GPIOB,GPIO_Pin_9);
            GPIO_ResetBits(GPIOB,GPIO_Pin_8);
            GPIO_ResetBits(GPIOA,GPIO_Pin_8);
            GPIO_ResetBits(GPIOC,GPIO_Pin_9);
            //ult0.ech_data=0;
           // ult1.ech_data=0;
           // ult2.ech_data=0;
           // ult3.ech_data=0;
          //  ult4.ech_data=0;
          //  ult5.ech_data=0;
          }
          else if(ultraChanSelect==ultra3_4)
          {
            GPIO_ResetBits(GPIOE,GPIO_Pin_1);
            GPIO_ResetBits(GPIOE,GPIO_Pin_0);
            GPIO_SetBits(GPIOB,GPIO_Pin_9);
            GPIO_SetBits(GPIOB,GPIO_Pin_8);
            GPIO_ResetBits(GPIOA,GPIO_Pin_8);
            GPIO_ResetBits(GPIOC,GPIO_Pin_9);
           // ult0.ech_data=0;
          //  ult1.ech_data=0;
          //  ult2.ech_data=0;
         //   ult3.ech_data=0;
         //   ult4.ech_data=0;
         //   ult5.ech_data=0;
          }
          else if(ultraChanSelect==ultra5_6)
          {
            GPIO_ResetBits(GPIOE,GPIO_Pin_1);
            GPIO_ResetBits(GPIOE,GPIO_Pin_0);
            GPIO_ResetBits(GPIOB,GPIO_Pin_9);
            GPIO_ResetBits(GPIOB,GPIO_Pin_8);
            GPIO_SetBits(GPIOA,GPIO_Pin_8);
            GPIO_SetBits(GPIOC,GPIO_Pin_9);
           // ult0.ech_data=0;
          //  ult1.ech_data=0;
          //  ult2.ech_data=0;
         //   ult3.ech_data=0;
          //  ult4.ech_data=0;
         //   ult5.ech_data=0;
          }
	}
	else 
	{
            GPIO_ResetBits(GPIOE,GPIO_Pin_1);
            GPIO_ResetBits(GPIOE,GPIO_Pin_0);
            GPIO_ResetBits(GPIOB,GPIO_Pin_9);
            GPIO_ResetBits(GPIOB,GPIO_Pin_8);
            GPIO_ResetBits(GPIOA,GPIO_Pin_8);
            GPIO_ResetBits(GPIOC,GPIO_Pin_9);
	}
        
        
        
	ult0.ech_up_down=ult0.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12);
	if(ult0.ech_up_down==0x7f)//up 7f
	{
		ult0.ech_cnt=micros();
	}
	if(ult0.ech_up_down==0x80)//down
	{
		ult0.ech_data=micros()-ult0.ech_cnt;
	}        
	ult1.ech_up_down=ult1.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13);
	if(ult1.ech_up_down==0x7f)//up 7f
	{
		ult1.ech_cnt=micros();
	}
	if(ult1.ech_up_down==0x80)//down
	{
		ult1.ech_data=micros()-ult1.ech_cnt;
	}
	
	ult2.ech_up_down=ult2.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14);
	if(ult2.ech_up_down==0x7f)//up
	{
		ult2.ech_cnt=micros();
	}
	if(ult2.ech_up_down==0x80)//down
	{
		ult2.ech_data=micros()-ult2.ech_cnt;		
	}
	
	ult3.ech_up_down=ult3.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15);
	if(ult3.ech_up_down==0x7f)//up
	{
		ult3.ech_cnt=micros();
	}
	if(ult3.ech_up_down==0x80)//down
	{
          ult3.ech_data=micros()-ult3.ech_cnt;//(u16)(tt>>3);
	}
	ult4.ech_up_down=ult4.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_8);
	if(ult4.ech_up_down==0x7f)//up
	{
		ult4.ech_cnt=micros();
	}
	if(ult4.ech_up_down==0x80)//down
	{
		ult4.ech_data=micros()-ult4.ech_cnt;			
	} 
	ult5.ech_up_down=ult5.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_9);
	if(ult5.ech_up_down==0x7f)//up
	{
		ult5.ech_cnt=micros();
	}
	if(ult5.ech_up_down==0x80)//down
	{
		ult5.ech_data=micros()-ult5.ech_cnt;		
	}
}

#ifdef __cplusplus
extern "C" {
#endif 
void SysTick_Handler()
{  	
    trig_cnt++;		
    time_10us_count++;
    if(time_10us_count>=100)
    {
      time_1ms_count++;
      time_50ms_cnt++;
      cmd_lost_time++;
      time_10us_count=0;
    }
    if (time_1ms_count >= (1000/CTRL_FREQ)) {
      time_control_flag = 1;
      time_1ms_count = 0;
    }
    if(time_50ms_cnt>=20)
    {
      time_50ms_flag=1;
      time_50ms_cnt=0;
    }
}

#ifdef __cplusplus
}
#endif
