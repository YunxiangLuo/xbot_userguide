/***************************************************
**HAL.c
**主要用于芯片硬件的内部外围和外部外围的初始化，两大INIT函数
**在MAIN中调用，使MAIN函数中尽量与硬件库无关
***************************************************/
#include "hal.h"

u8 led_st=0;
u8 battery_st=0;
u8 imu_st=0;

void ledFlash(void)
{
	if(led_st)
	{
		LED_ON;
		led_st=0;
	}
	else
	{
		LED_OFF;
		led_st=1;
	}
}
void ledBattery(void)
{
	if(battery_st)
	{	
		BATTERY_ON;
		battery_st=0;
	}
	else
	{	
		BATTERY_OFF;
		battery_st=1;
	}
}
void ledImu(void)
{
	if(led_st)
	{	
		IMU_ON;
		imu_st=0;
	}
	else
	{	
		IMU_OFF;
		imu_st=1;
	}
}

void delayUs(u32 n) {
	u8 j;
	while (n--)
		for (j = 0; j < 20; j++)
			;		                                                  //72M?j<20
}
void delayMs(u32 n) {
	while (n--)
		delayUs(1000);
}
/*******************************
**函数名:chipHalInit()
**功能:片内硬件初始化
*******************************/


void  chipHalInit(void)
{	
	//初始化时钟源
	rccConfiguration();	
	
	//初始化EXIT
	exitConfiguration();
	
	//初始化NVIC
	nvicConfiguration();	
	
	//初始化GPIO
	gpioConfiguration();
	
	//初始化串口
	usartConfiguration();	
	
	//初始化TIM
	timerConfiguration();
	
	//初始化ADC
        adcDmaInit(); 
	
	//初始SysTick
	sysTickInit();
}


/*********************************
**函数名:chipOutHalInit()
**功能:片外硬件初始化
*********************************/
void  chipOutHalInit(void)
{
	
}









