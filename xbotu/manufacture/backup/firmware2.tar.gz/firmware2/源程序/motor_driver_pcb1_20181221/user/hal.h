#ifndef __HAL_H__
#define __HAL_H__
	
#include "stm32f10x.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_it.h"

#include "motor.h"
#include "USART.h"
#include "battery.h"

//输出宏定义
#define LED_ON		GPIO_ResetBits(GPIOE, GPIO_Pin_3)
#define LED_OFF		GPIO_SetBits(GPIOE, GPIO_Pin_3)

#define BATTERY_ON		GPIO_ResetBits(GPIOE, GPIO_Pin_4)
#define BATTERY_OFF		GPIO_SetBits(GPIOE, GPIO_Pin_4)

#define IMU_ON		GPIO_ResetBits(GPIOC, GPIO_Pin_5)
#define IMU_OFF		GPIO_SetBits(GPIOC, GPIO_Pin_5)

#define ASUS_OFF	GPIO_ResetBits(GPIOA, GPIO_Pin_11)
#define ASUS_ON  	GPIO_SetBits(GPIOA, GPIO_Pin_11)

#define POWER_OFF		GPIO_ResetBits(GPIOE, GPIO_Pin_2)
#define POWER_ON		GPIO_SetBits(GPIOE, GPIO_Pin_2)

#define MOTOR1_DISABLE		GPIO_ResetBits(GPIOE, GPIO_Pin_12)
#define MOTOR1_ENABLE		GPIO_SetBits(GPIOE, GPIO_Pin_12)

#define MOTOR2_DISABLE		GPIO_ResetBits(GPIOD, GPIO_Pin_10)
#define MOTOR2_ENABLE		GPIO_SetBits(GPIOD, GPIO_Pin_10)

#define ON		1
#define OFF		0

typedef enum {
  ultra1_2=0,
  ultra3_4,
  ultra5_6
}Ultra;



typedef struct {
  u8 ech_up_down; 
  u16 ech_cnt; 
  u16 Ech_data_buf;
  u16 ech_data;
  u16 Ech_data_pre;
}CaptureTypedef;

typedef enum {
  speed_cmd=0,
  X_distance_cmd,
  Y_distance_cmd,
  Z_rotation_cmd
} Cmd;


void ledFlash(void);
void ledBattery(void);
void ledImu(void);

void delayUs(u32 n);
void delayMs(u32 n);
//硬件初始化
void  chipHalInit(void);
void  chipOutHalInit(void);

//各个内部硬件模块的配置函数
extern void gpioConfiguration(void);			//GPIO
extern void rccConfiguration(void);			//RCC
extern void usartConfiguration(void);			//串口
extern void nvicConfiguration(void);			//NVIC
extern void exitConfiguration(void);			//NVIC
extern void timerConfiguration(void);
extern void sysTickInit(void);
extern void adcDmaInit(void);

extern uint16_t adc_convertedvalut[11];
extern Motor1	motor_1;
extern Motor2	motor_2;
extern Com1 com1;
extern Com2 usart2_com;
extern Com3 usart3_com;
extern Battery battery1,battery2;

#endif


