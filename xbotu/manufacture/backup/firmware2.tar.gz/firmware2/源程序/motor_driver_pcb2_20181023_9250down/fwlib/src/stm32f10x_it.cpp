/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* stm32f10x_it.c
* ?����D?D???����|o����y��?��?��?��?1??D??����???��������??��?��?��?����?����D���?��??��
* ?���̡¨�?HAL?��?��?D?�¡�???��|��?��|����o����y��|����?D???��
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "USART.h"
#include "motor.h"
#include "hal.h"
/* Private typedef -----------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
#define countof(a)   (sizeof(a) / sizeof(*(a)))

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : NMI_Handler
* Description    : This function handles NMI exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NMI_Handler(void)
{
	
}

/*******************************************************************************
* Function Name  : HardFault_Handler
* Description    : This function handles Hard Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/


void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {

  }
}

/*******************************************************************************
* Function Name  : MemManage_Handler
* Description    : This function handles Memory Manage exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : BusFault_Handler
* Description    : This function handles Bus Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : UsageFaultException
* Description    : This function handles Usage Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : SVC_Handler
* Description    : This function handles SVCall exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SVC_Handler(void)
{
}

/*******************************************************************************
* Function Name  : DebugMon_Handler
* Description    : This function handles Debug Monitor exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DebugMon_Handler(void)
{
}

/*******************************************************************************
* Function Name  : PendSVC
* Description    : This function handles PendSVC exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void PendSV_Handler(void)
{
}

/*******************************************************************************
* Function Name  : SysTickHandler
* Description    :
*******************************************************************************/
  

/*******************************************************************************
* Function Name  : WWDG_IRQHandler
* Description    : This function handles WWDG interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void WWDG_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : PVD_IRQHandler
* Description    : This function handles PVD interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void PVD_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : TAMPER_IRQHandler
* Description    : This function handles Tamper interrupt request. 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TAMPER_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : RTC_IRQHandler   
* Description    : RTC?D???D��?
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RTC_IRQHandler(void)
{

}

/*******************************************************************************
* Function Name  : FLASH_IRQHandler
* Description    : This function handles Flash interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void FLASH_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : RCC_IRQHandler
* Description    : This function handles RCC interrupt request. 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RCC_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : EXTI0_IRQHandler
* Description    : This function handles External interrupt Line 0 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EXTI0_IRQHandler(void)
{ 
  if (EXTI_GetITStatus(EXTI_Line0) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line0);
     }
}

/*******************************************************************************
* Function Name  : EXTI1_IRQHandler
* Description    : This function handles External interrupt Line 1 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EXTI1_IRQHandler(void)
{ 
  if (EXTI_GetITStatus(EXTI_Line1) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line1);
     }
}

/*******************************************************************************
* Function Name  : EXTI2_IRQHandler
* Description    : This function handles External interrupt Line 2 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EXTI2_IRQHandler(void)
{
  if (EXTI_GetITStatus(EXTI_Line2) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line2);
     }     
}

/*******************************************************************************
* Function Name  : EXTI3_IRQHandler
* Description    : This function handles External interrupt Line 3 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EXTI3_IRQHandler(void)
{
   if (EXTI_GetITStatus(EXTI_Line3) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line3);
     }      
}

/*******************************************************************************
* Function Name  : EXTI4_IRQHandler
* Description    : This function handles External interrupt Line 4 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EXTI4_IRQHandler(void)
{
   if (EXTI_GetITStatus(EXTI_Line4) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line4);
     } 
}

/*******************************************************************************
* Function Name  : DMAChannel1_IRQHandler
* Description    : This function handles DMA Stream 1 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel1_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : DMAChannel2_IRQHandler
* Description    : This function handles DMA Stream 2 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel2_IRQHandler(void)
{
   DMA_ClearFlag(DMA1_FLAG_TC2);        // ȥԽҪ־λ  
   DMA_Cmd(DMA1_Channel2,DISABLE);      // ژҕDMA 
   
}

/*******************************************************************************
* Function Name  : DMAChannel3_IRQHandler
* Description    : This function handles DMA Stream 3 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel3_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : DMAChannel4_IRQHandler
* Description    : This function handles DMA Stream 4 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel4_IRQHandler(void)
{
   DMA_ClearFlag(DMA1_FLAG_TC4);        // ????λ  
   DMA_Cmd(DMA1_Channel4,DISABLE);      // ??DMA 

//   DMA_ClearFlag(DMA1_FLAG_TC4);        // �����־λ  
//   DMA_Cmd(DMA1_Channel4,DISABLE);      // �ر�DMA 
//   DMA_ClearFlag(DMA1_FLAG_GL4);        // ȥԽҪ־λ  
//   DMA_Cmd(DMA1_Channel4,DISABLE);      // ژҕDMA    
//   
//   DMA_ClearFlag(DMA1_FLAG_HT4);        // ȥԽҪ־λ  
//   DMA_Cmd(DMA1_Channel4,DISABLE);      // ژҕDMA    
//   DMA_ClearFlag(DMA1_FLAG_TE4);        // ȥԽҪ־λ  
//   DMA_Cmd(DMA1_Channel4,DISABLE);      // ژҕDMA    
}

/*******************************************************************************
* Function Name  : DMAChannel5_IRQHandler
* Description    : This function handles DMA Stream 5 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel5_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : DMAChannel6_IRQHandler
* Description    : This function handles DMA Stream 6 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel6_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : DMAChannel7_IRQHandler
* Description    : This function handles DMA Stream 7 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA1_Channel7_IRQHandler(void)
{
   DMA_ClearFlag(DMA1_FLAG_TC7);        // ȥԽҪ־λ  
   DMA_Cmd(DMA1_Channel7,DISABLE);      // ژҕDMA 
}

/*******************************************************************************
* Function Name  : ADC_IRQHandler
* Description    : This function handles ADC global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ADC1_2_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : USB_HP_CAN_TX_IRQHandler
* Description    : This function handles USB High Priority or CAN TX interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USB_HP_CAN1_TX_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : USB_LP_CAN_RX0_IRQHandler
* Description    : This function handles USB Low Priority or CAN RX0 interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USB_LP_CAN1_RX0_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : CAN_RX1_IRQHandler
* Description    : This function handles CAN RX1 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CAN1_RX1_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : CAN_SCE_IRQHandler
* Description    : This function handles CAN SCE interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CAN1_SCE_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : EXTI9_5_IRQHandler
* Description    : This function handles External lines 9 to 5 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

extern uint32_t micros(void);
void EXTI9_5_IRQHandler(void)
{
   if (EXTI_GetITStatus(EXTI_Line5) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line5);
     }   
   if (EXTI_GetITStatus(EXTI_Line6) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line6);
     }  
   if (EXTI_GetITStatus(EXTI_Line7) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line7);
     } 
}

/*******************************************************************************
* Function Name  : TIM1_BRK_IRQHandler
* Description    : This function handles TIM1 Break interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM1_BRK_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : TIM1_UP_IRQHandler
* Description    : This function handles TIM1 overflow and update interrupt 
*                  request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM1_UP_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : TIM1_TRG_COM_IRQHandler
* Description    : This function handles TIM1 Trigger and commutation interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM1_TRG_COM_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : TIM1_CC_IRQHandler
* Description    : This function handles TIM1 capture compare interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM1_CC_IRQHandler(void)
{

}

/*******************************************************************************
* Function Name  : TIM2_IRQHandler TIM2?D??
* Description    : This function handles TIM2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}

/*******************************************************************************
* Function Name  : TIM3_IRQHandler
* Description    : This function handles TIM3 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}

/*******************************************************************************
* Function Name  : TIM4_IRQHandler
* Description    : This function handles TIM4 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM4_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : I2C1_EV_IRQHandler
* Description    : This function handles I2C1 Event interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C1_EV_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : I2C1_ER_IRQHandler
* Description    : This function handles I2C1 Error interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C1_ER_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : I2C2_EV_IRQHandler
* Description    : This function handles I2C2 Event interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C2_EV_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : I2C2_ER_IRQHandler
* Description    : This function handles I2C2 Error interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C2_ER_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : SPI1_IRQHandler
* Description    : This function handles SPI1 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI1_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : SPI2_IRQHandler
* Description    : This function handles SPI2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI2_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : USART1_IRQHandler
* Description    : This function handles USART1 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
extern u8 rx1buf[UART1_RXSIZE];
extern u8 rx1head;
extern u8 rx1tail;
extern u8 tx1buf[UART1_TXSIZE];
extern u8 tx1head;
extern u8 tx1tail;

void USART1_IRQHandler(void)
{
    if(USART_GetFlagStatus(USART1,USART_FLAG_ORE)==SET)
    {
        USART_ClearFlag(USART1,USART_FLAG_ORE);    //?ȢSR
        USART_ReceiveData(USART1);                //?ȢDR
    }
	//?ȮȺ??D??
    if(USART_GetITStatus(USART1,USART_IT_RXNE)==SET)
    {
	  	 u8 tmphead;
		 u8 data;
		data = USART_ReceiveData(USART1); 				/* read the received data */
		tmphead = (rx1head + 1) ;						/* calculate buffer index */
		tmphead %= UART1_RXSIZE;
		rx1head = tmphead; 								/* store new index */
		
		USART_ClearITPendingBit(USART1,USART_IT_RXNE); 

        rx1buf[tmphead]= data;		
    }
    
    if(USART_GetITStatus(USART1,USART_IT_TXE)==SET)
	{
	  	 u8 tmptail;
        USART_ClearITPendingBit(USART1,USART_IT_TXE);
        if ( tx1head != tx1tail ){
		  	tmptail = ( tx1tail + 1 ) ;					/* calculate buffer index */
			tmptail %= UART1_TXSIZE ;
			tx1tail = tmptail; 							/* store new index */
            USART_SendData(USART1, tx1buf[tmptail]);
        }
        else{
            USART_ITConfig(USART1,USART_IT_TXE,DISABLE);			
        }
    }
}
/*******************************************************************************
* Function Name  : USART2_IRQHandler
* Description    : This function handles USART2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
extern u8 rx2buf[UART2_RXSIZE];
extern u8 rx2head;
extern u8 rx2Tail;
extern u8 tx2buf[UART2_TXSIZE];
extern u8 tx2head;
extern u8 tx2Tail;
void USART2_IRQHandler(void)
{
    if(USART_GetFlagStatus(USART2,USART_FLAG_ORE)==SET)
    {
        USART_ClearFlag(USART2,USART_FLAG_ORE);    //?ȢSR
        USART_ReceiveData(USART2);                //?ȢDR
    }
	//?ȮȺ??D??
    if(USART_GetITStatus(USART2,USART_IT_RXNE)==SET)
    {
	  	 u8 tmphead;
		 u8 data;
		data = USART_ReceiveData(USART2); 				/* read the received data */
		tmphead = (rx2head + 1) ;						/* calculate buffer index */
		tmphead %= UART2_RXSIZE;
		rx2head = tmphead; 								/* store new index */
		
		USART_ClearITPendingBit(USART2,USART_IT_RXNE); 

        rx2buf[tmphead]= data;	
		//USART_SendData(USART1, data);
    }
    
    if(USART_GetITStatus(USART2,USART_IT_TXE)==SET)
	{
	  	 u8 tmptail;
        USART_ClearITPendingBit(USART2,USART_IT_TXE);
        if ( tx2head != tx2Tail ){
		  	tmptail = ( tx2Tail + 1 ) ;					/* calculate buffer index */
			tmptail %= UART2_TXSIZE ;
			tx2Tail = tmptail; 							/* store new index */
            USART_SendData(USART2, tx2buf[tmptail]);
        }
        else{
            USART_ITConfig(USART2,USART_IT_TXE,DISABLE);			
        }
    }
}

/*******************************************************************************
* Function Name  : USART3_IRQHandler
* Description    : This function handles USART3 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
extern u8 rx3buf[UART3_RXSIZE];
extern u8 rx3head;
extern u8 rx3Tail;
extern u8 tx3buf[UART3_TXSIZE];
extern u8 tx3head;
extern u8 tx3Tail;
void USART3_IRQHandler(void)
{  
    if(USART_GetFlagStatus(USART3,USART_FLAG_ORE)==SET)
    {
        USART_ClearFlag(USART3,USART_FLAG_ORE);    //?ȢSR
        USART_ReceiveData(USART3);                //?ȢDR
    }
	//?ȮȺ??D??
    if(USART_GetITStatus(USART3,USART_IT_RXNE)==SET)
    {
	  	 u8 tmphead;
		 u8 data;
		data = USART_ReceiveData(USART3); 				/* read the received data */
		tmphead = (rx3head + 1) ;						/* calculate buffer index */
		tmphead %= UART3_RXSIZE;
		rx3head = tmphead; 								/* store new index */
		
		USART_ClearITPendingBit(USART3,USART_IT_RXNE); 
		
               rx3buf[tmphead]= data;	
		//USART_SendData(USART1, data);
    }
    
    if(USART_GetITStatus(USART3,USART_IT_TXE)==SET)
	{
	  	 u8 tmptail;
        USART_ClearITPendingBit(USART3,USART_IT_TXE);
        if ( tx3head != tx3Tail ){
		  	tmptail = ( tx3Tail + 1 ) ;					/* calculate buffer index */
			tmptail %= UART3_TXSIZE ;
			tx3Tail = tmptail; 							/* store new index */
            USART_SendData(USART3, tx3buf[tmptail]);
        }
        else{
            USART_ITConfig(USART3,USART_IT_TXE,DISABLE);			
        }
    }
}

/*******************************************************************************
* Function Name  : EXTI15_10_IRQHandler
* Description    : This function handles External lines 15 to 10 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EXTI15_10_IRQHandler(void)
{
   if (EXTI_GetITStatus(EXTI_Line11) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line11);
     } 
   if (EXTI_GetITStatus(EXTI_Line12) != RESET) { 
       EXTI_ClearITPendingBit(EXTI_Line12);
     }
}

/*******************************************************************************
* Function Name  : RTCAlarm_IRQHandler
* Description    : This function handles RTC Alarm interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RTCAlarm_IRQHandler(void)
{
}

/*******************************************************************************
* Function Name  : USBWakeUp_IRQHandler
* Description    : This function handles USB WakeUp interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USBWakeUp_IRQHandler(void)
{
}

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
  
