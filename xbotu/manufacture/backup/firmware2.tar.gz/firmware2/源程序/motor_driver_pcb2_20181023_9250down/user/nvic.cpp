#include "stm32f10x.h" 

//设置所有的中断允许

void nvicConfiguration(void)
{
	NVIC_InitTypeDef nvicInitStructure;
	
	/* Configure one bit for preemption priority */
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);

		/*DMA1*/
	nvicInitStructure.NVIC_IRQChannel = DMA1_Channel4_IRQn;
	nvicInitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	nvicInitStructure.NVIC_IRQChannelSubPriority = 0;
	nvicInitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&nvicInitStructure);

		/*DMA1*/
	nvicInitStructure.NVIC_IRQChannel = DMA1_Channel7_IRQn;
	nvicInitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	nvicInitStructure.NVIC_IRQChannelSubPriority = 0;
	nvicInitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&nvicInitStructure);	    


		/**/
	nvicInitStructure.NVIC_IRQChannel = USART1_IRQn;
	nvicInitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	nvicInitStructure.NVIC_IRQChannelSubPriority = 0;
	nvicInitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&nvicInitStructure);

		/**/
	nvicInitStructure.NVIC_IRQChannel = USART2_IRQn;
	nvicInitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	nvicInitStructure.NVIC_IRQChannelSubPriority = 0;
	nvicInitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&nvicInitStructure);	
		/**/
	nvicInitStructure.NVIC_IRQChannel = USART3_IRQn;
	nvicInitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	nvicInitStructure.NVIC_IRQChannelSubPriority = 0;
	nvicInitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&nvicInitStructure);	

}
