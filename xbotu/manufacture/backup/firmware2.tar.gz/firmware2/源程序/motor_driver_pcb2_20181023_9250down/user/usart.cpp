#include "string.h"
#include "stm32f10x.h"

#include "USART.h"

u8 rx1buf[UART1_RXSIZE];
u8 rx1head;
u8 rx1tail;
u8 tx1buf[UART1_TXSIZE];
u8 tx1head;
u8 tx1tail;

u8 rx2buf[UART2_RXSIZE];
u8 rx2head;
u8 rx2Tail;
u8 tx2buf[UART2_TXSIZE];
u8 tx2head;
u8 tx2Tail;

u8 rx3buf[UART3_RXSIZE];
u8 rx3head;
u8 rx3Tail;
u8 tx3buf[UART3_TXSIZE];
u8 tx3head;
u8 tx3Tail;

u8 rx4buf[UART4_RXSIZE];
u8 rx4head;
u8 rx4Tail;
u8 tx4buf[UART4_TXSIZE];
u8 tx4head;
u8 tx4Tail;

Com1 usart1_com;
Com2 usart2_com;
Com3 usart3_com;
Com4 usart4_com;
/**********************************************
**串口配置函数,这里使能了两个串口,其中串口2使用了中断接收模式
**
**********************************************/
void usartConfiguration(void)
{
    DMA_InitTypeDef dma_initstructure;
    GPIO_InitTypeDef gpio_initstructure;
    USART_InitTypeDef usart_initstructure;
    USART_ClockInitTypeDef usart_clockinitstructure;	
	
    /* A9 USART1_Tx */
    gpio_initstructure.GPIO_Pin = GPIO_Pin_9;
    gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;
    gpio_initstructure.GPIO_Mode = GPIO_Mode_AF_PP;		//推挽输出-TX
    GPIO_Init(GPIOA, &gpio_initstructure);

    /* A10 USART1_Rx  */
    gpio_initstructure.GPIO_Pin = GPIO_Pin_10;
    gpio_initstructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//浮空输入-RX
    GPIO_Init(GPIOA, &gpio_initstructure);	

	
    usart_initstructure.USART_BaudRate = 115200;
    usart_initstructure.USART_WordLength = USART_WordLength_8b;
    usart_initstructure.USART_StopBits = USART_StopBits_1;
    usart_initstructure.USART_Parity = USART_Parity_No;
    usart_initstructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart_initstructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    
    usart_clockinitstructure.USART_Clock = USART_Clock_Disable;
    usart_clockinitstructure.USART_CPOL = USART_CPOL_Low;
    usart_clockinitstructure.USART_CPHA = USART_CPHA_2Edge;
    usart_clockinitstructure.USART_LastBit = USART_LastBit_Disable;

    USART_ClockInit(USART1, &usart_clockinitstructure);
    USART_Init(USART1, &usart_initstructure);
	
    USART_Cmd(USART1, ENABLE);
	
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);	
	
   /* Init DMA1_Channel4 */
    DMA_Cmd(DMA1_Channel4, DISABLE);                                    // 关DMA通道
    DMA_DeInit(DMA1_Channel4);                                          // 恢复缺省值
    dma_initstructure.DMA_PeripheralBaseAddr = (u32) (&USART1->DR);     //设置DMA的外设地址为UART1   
    dma_initstructure.DMA_DIR = DMA_DIR_PeripheralDST;                  //设置外设地址作为DMA目的地址
    dma_initstructure.DMA_MemoryBaseAddr = (u32)(&tx1buf);          	//定义DMA基地址
    dma_initstructure.DMA_BufferSize = UART1_TXSIZE;                    //设置DMA在传输时缓冲区的长度word
    dma_initstructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;    //DMA外设地址不变
    dma_initstructure.DMA_MemoryInc = DMA_MemoryInc_Enable;             //设置DMA的内存递增模式
    dma_initstructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte; //数据宽度为8位
    dma_initstructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;     //数据宽度为8位
    dma_initstructure.DMA_Mode = DMA_Mode_Normal;                        //设置DMA的传输模式，正常模式，只传送一次;
    dma_initstructure.DMA_Priority = DMA_Priority_Medium;               //设置DMA的优先级别
    dma_initstructure.DMA_M2M = DMA_M2M_Disable;                        //设置DMA的2个memory中的变量互相访问
    DMA_Init(DMA1_Channel4, &dma_initstructure);
     
    USART_DMACmd(USART1,USART_DMAReq_Tx,ENABLE);                        //采用DMA方式发送 	//启动串口  
    DMA_ITConfig(DMA1_Channel4, DMA_IT_TC, ENABLE);                     //传输完成则进入DMA1_Channel7中断	

    
    
	/* A2 USART2_Tx */
    gpio_initstructure.GPIO_Pin = GPIO_Pin_2;
    gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;
    gpio_initstructure.GPIO_Mode = GPIO_Mode_AF_PP;		//推挽输出-TX
    GPIO_Init(GPIOA, &gpio_initstructure);

    /* A3 USART2_Rx  */
    gpio_initstructure.GPIO_Pin = GPIO_Pin_3;
    gpio_initstructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//浮空输入-RX
    GPIO_Init(GPIOA, &gpio_initstructure);	

	
    usart_initstructure.USART_BaudRate = 115200;
    usart_initstructure.USART_WordLength = USART_WordLength_8b;
    usart_initstructure.USART_StopBits = USART_StopBits_1;
    usart_initstructure.USART_Parity = USART_Parity_No;
    usart_initstructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart_initstructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    
    usart_clockinitstructure.USART_Clock = USART_Clock_Disable;
    usart_clockinitstructure.USART_CPOL = USART_CPOL_Low;
    usart_clockinitstructure.USART_CPHA = USART_CPHA_2Edge;
    usart_clockinitstructure.USART_LastBit = USART_LastBit_Disable;

    USART_ClockInit(USART2, &usart_clockinitstructure);
    USART_Init(USART2, &usart_initstructure);
	
    USART_Cmd(USART2, ENABLE);
	
    USART_ITConfig(USART2, USART_IT_RXNE , ENABLE);

   /* Init DMA1_Channel7 */
    DMA_Cmd(DMA1_Channel7, DISABLE);                                    // 关DMA通道
    DMA_DeInit(DMA1_Channel7);                                          // 恢复缺省值
    dma_initstructure.DMA_PeripheralBaseAddr = (u32) (&USART2->DR);     //设置DMA的外设地址为UART2    
    dma_initstructure.DMA_DIR = DMA_DIR_PeripheralDST;                  //设置外设地址作为DMA目的地址
    dma_initstructure.DMA_MemoryBaseAddr = (u32)(&tx2buf);          	//定义DMA基地址
    dma_initstructure.DMA_BufferSize = UART2_TXSIZE;                    //设置DMA在传输时缓冲区的长度word
    dma_initstructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;    //DMA外设地址不变
    dma_initstructure.DMA_MemoryInc = DMA_MemoryInc_Enable;             //设置DMA的内存递增模式
    dma_initstructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte; //数据宽度为8位
    dma_initstructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;     //数据宽度为8位
    dma_initstructure.DMA_Mode = DMA_Mode_Normal;                        //设置DMA的传输模式，正常模式，只传送一次;
    dma_initstructure.DMA_Priority = DMA_Priority_Medium;               //设置DMA的优先级别
    dma_initstructure.DMA_M2M = DMA_M2M_Disable;                        //设置DMA的2个memory中的变量互相访问
    DMA_Init(DMA1_Channel7, &dma_initstructure);
     
    USART_DMACmd(USART2,USART_DMAReq_Tx,ENABLE);                        //采用DMA方式发送 	//启动串口  
    DMA_ITConfig(DMA1_Channel7, DMA_IT_TC, ENABLE);                     //传输完成则进入DMA1_Channel7中断	    
	    
    
    GPIO_PinRemapConfig(GPIO_FullRemap_USART3, ENABLE);
	/* B10 USART3_Tx */
    gpio_initstructure.GPIO_Pin = GPIO_Pin_8;
    gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;
    gpio_initstructure.GPIO_Mode = GPIO_Mode_AF_PP;		//推挽输出-TX
    GPIO_Init(GPIOD, &gpio_initstructure);

    /* B11 USART3_Rx  */
    gpio_initstructure.GPIO_Pin = GPIO_Pin_9;
    gpio_initstructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//浮空输入-RX
    GPIO_Init(GPIOD, &gpio_initstructure);	

	
    usart_initstructure.USART_BaudRate = 115200;
    usart_initstructure.USART_WordLength = USART_WordLength_8b;
    usart_initstructure.USART_StopBits = USART_StopBits_1;
    usart_initstructure.USART_Parity = USART_Parity_No;
    usart_initstructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart_initstructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    
    usart_clockinitstructure.USART_Clock = USART_Clock_Disable;
    usart_clockinitstructure.USART_CPOL = USART_CPOL_Low;
    usart_clockinitstructure.USART_CPHA = USART_CPHA_2Edge;
    usart_clockinitstructure.USART_LastBit = USART_LastBit_Disable;

    USART_ClockInit(USART3, &usart_clockinitstructure);
    USART_Init(USART3, &usart_initstructure);
	
    USART_Cmd(USART3, ENABLE);
	
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);	
    USART_ClearFlag(USART3,USART_FLAG_TC);
}

 u8 usart1GetByte(u8* pChar)
{
	unsigned char tmptail;	
	if( rx1head != rx1tail )
	{
		USART_ITConfig(USART1,USART_IT_RXNE,DISABLE);  //禁止接收
		tmptail = ( rx1tail + 1 ) ;
		tmptail %= UART1_RXSIZE ;		/* calculate buffer index */
		rx1tail = tmptail; 			/* store new index */
		tmptail = rx1buf[tmptail];
		USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
		*pChar = tmptail; 						/* return data */
		return 1;
	}
  	return 0;	
}
 u8 usart2GetByte(u8* pChar)
{
	unsigned char tmptail;	
	if( rx2head != rx2Tail )
	{
		USART_ITConfig(USART2,USART_IT_RXNE,DISABLE);  //禁止接收
		tmptail = ( rx2Tail + 1 ) ;
		tmptail %= UART2_RXSIZE ;		/* calculate buffer index */
		rx2Tail = tmptail; 			/* store new index */
		tmptail = rx2buf[tmptail];
		USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
		*pChar = tmptail; 						/* return data */
		return 1;
	}
  	return 0;	
}
 u8 usart3GetByte(u8* pChar)
{
	unsigned char tmptail;	
	if( rx3head != rx3Tail )
	{
		USART_ITConfig(USART3,USART_IT_RXNE,DISABLE);  //禁止接收
		tmptail = ( rx3Tail + 1 ) ;
		tmptail %= UART3_RXSIZE ;		/* calculate buffer index */
		rx3Tail = tmptail; 			/* store new index */
		tmptail = rx3buf[tmptail];
		USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);
		*pChar = tmptail; 						/* return data */
		return 1;
	}
  	return 0;	
}
 u8 usart4GetByte(u8* pChar)
{
	unsigned char tmptail;	
	if( rx4head != rx4Tail )
	{
		USART_ITConfig(UART4,USART_IT_RXNE,DISABLE);  //禁止接收
		tmptail = ( rx4Tail + 1 ) ;
		tmptail %= UART4_RXSIZE ;		/* calculate buffer index */
		rx4Tail = tmptail; 			/* store new index */
		tmptail = rx4buf[tmptail];
		USART_ITConfig(UART4,USART_IT_RXNE,ENABLE);
		*pChar = tmptail; 						/* return data */
		return 1;
	}
  	return 0;	
}
/**
 * 开启一次DMA传输 
 *      DMA_CHx : DMA1 通道
 *      cmar : 存储器地址
 *      cndtr : 数据传输量
*/
void USART_DMA_Enable(DMA_Channel_TypeDef* DMA_CHx, u32 cmar, u16 cndtr) {  
    DMA_CHx->CCR &= ~(1<<0);        //关闭DMA传输   
    DMA_CHx->CNDTR = cndtr;          //DMA1,传输数据量配置 
    DMA_CHx->CMAR = (u32)cmar;      //DMA1,存储器地址
    DMA_CHx->CCR |= 1<<0;           //开启DMA传输  
}

Qrobot_interface::Qrobot_interface() :
	  rx_wr_index(0), rx_wr_size(0),  checksum(0){

	memset(tx_buf, 0, sizeof(tx_buf));
    memset(rx_buf, 0, sizeof(rx_buf));
	memset(tmp_buf, 0, sizeof(tmp_buf));		
}

Qrobot_interface::~Qrobot_interface() {
  
}

Com1::Com1() {
        tx_buf[0] = 0xAA; 	//  header00
	tx_buf[1] = 0x55;	//	header01
	tx_buf[2] = 0x47;
	tx_buf[3] = 0x11;
	memcpy(tmp_buf, tx_buf, sizeof(tmp_buf));
}
Com1::~Com1() {
  
}

Com2::Com2() {
        tx_buf[0] = 0xDD; 	//  header00
	tx_buf[1] = 0xA5;	//	header01
	tx_buf[2] = 0x03;
	tx_buf[3] = 0x00 ;
	tx_buf[4] = 0xFF;
	tx_buf[5] = 0xFD; 
	tx_buf[6] = 0x77;
}
Com2::~Com2() {
  
}

Com3::Com3() {
        tx_buf[0] = 0xDD; 	//  header00
	tx_buf[1] = 0xA5;	//	header01
	tx_buf[2] = 0x03;
	tx_buf[3] = 0x00 ;
	tx_buf[4] = 0xFF;
	tx_buf[5] = 0xFD; 
	tx_buf[6] = 0x77;
}
Com3::~Com3() {
  
}

Com4::Com4() {
        tx_buf[0] = 0xDD; 	//  header00
	tx_buf[1] = 0xA5;	//	header01
	tx_buf[2] = 0x03;
	tx_buf[3] = 0x00 ;
	tx_buf[4] = 0xFF;
	tx_buf[5] = 0xFD; 
	tx_buf[6] = 0x77;
}
Com4::~Com4() {
  
}


u8 Qrobot_interface::decodeFrame(unsigned char adata) {
    u8 i,j;
    if ((adata != 0xAA) && (rx_wr_index == 0)) {       
        return 0;
    }      
    rx_buf[rx_wr_index++] = adata;
	if(rx_wr_index >4 ){      
	  if(rx_wr_index == (rx_buf[2]+4))
          {     
		if (sumCheck()) { 
		  rx_wr_index=0;
		  return 1;
		} else {rx_wr_index=0;
//		  rx_wr_size=rx_wr_index;
//		  for(i=0; i<rx_wr_size-1; i++) {
//			if(rx_buf[i+1]==0xAA)
//				break;
//		  }
//		  for(j=i; j<rx_wr_size-1; j++)	{
//			rx_wr_index = j-i;
//			rx_buf[rx_wr_index] = rx_buf[j+1];
//		  }
//		  rx_wr_index += 1;
		}
	  }
          else
          {//rx_wr_index=0;
//		  rx_wr_size=rx_wr_index;
//		  for(i=0; i<rx_wr_size-1; i++) {
//			if(rx_buf[i]==0xAA)
//				break;
//		  }
//		  for(j=i; j<rx_wr_size-1; j++)	{
//			rx_wr_index = j-i;
//			rx_buf[rx_wr_index] = rx_buf[j+1];
//		  }
//		  rx_wr_index += 1;            
          }
	}
    return 0;    
}

u8 Qrobot_interface::decodeSteer(unsigned char adata) 
{
    u8 i,j;
    if ((adata != 0x55) && (rx_wr_index == 0)) {       
        return 0;
    } 
    
    rx_buf[rx_wr_index++] = adata;
	if(rx_wr_index >4 ){      
	  if(rx_wr_index == (rx_buf[3]+3))
          {     
		if (sumCheckSteer()) { 
		  rx_wr_index=0;
		  return 1;
		} else {rx_wr_index=0;
//		  rx_wr_size=rx_wr_index;
//		  for(i=0; i<rx_wr_size-1; i++) {
//			if(rx_buf[i+1]==0x55)
//				break;
//		  }
//		  for(j=i; j<rx_wr_size-1; j++)	{
//			rx_wr_index = j-i;
//			rx_buf[rx_wr_index] = rx_buf[j+1];
//		  }
//		  rx_wr_index += 1;
		}
	  }
          else
          {
//		  rx_wr_size=rx_wr_index;
//		  for(i=0; i<rx_wr_size-1; i++) {
//			if(rx_buf[i]==0xAA)
//				break;
//		  }
//		  for(j=i; j<rx_wr_size-1; j++)	{
//			rx_wr_index = j-i;
//			rx_buf[rx_wr_index] = rx_buf[j+1];
//		  }
//		  rx_wr_index += 1;            
          }
	}
    return 0;      
}
u8 Qrobot_interface::decodeIMU(unsigned char adata) 
{
    u8 i,j;
    if ((adata != 0xDD) && (rx_wr_index == 0)) {       
        return 0;
    } 
    
    rx_buf[rx_wr_index++] = adata;
	if(rx_wr_index >3 ){      
	  if(rx_wr_index == (rx_buf[3]+7))
          {     
		if (sumCheckSteer()) { 
		  rx_wr_index=0;
		  return 1;
		} else {rx_wr_index=0;
//		  rx_wr_size=rx_wr_index;
//		  for(i=0; i<rx_wr_size-1; i++) {
//			if(rx_buf[i+1]==0xDD)
//				break;
//		  }
//		  for(j=i; j<rx_wr_size-1; j++)	{
//			rx_wr_index = j-i;
//			rx_buf[rx_wr_index] = rx_buf[j+1];
//		  }
//		  rx_wr_index += 1;
		}
	  }
          else
          {
//		  rx_wr_size=rx_wr_index;
//		  for(i=0; i<rx_wr_size-1; i++) {
//			if(rx_buf[i]==0xAA)
//				break;
//		  }
//		  for(j=i; j<rx_wr_size-1; j++)	{
//			rx_wr_index = j-i;
//			rx_buf[rx_wr_index] = rx_buf[j+1];
//		  }
//		  rx_wr_index += 1;            
          }
	}
    return 0;      
}


void Com1::data_deal() { 
    //send data
    checksum=0;
    for (u8 i = 0; i < 74; i++)
		checksum ^= tx_buf[i];
    tx_buf[74] = checksum;
  
}
void Com3::data_deal() {  
}
unsigned char Qrobot_interface::sumCheck() {
	unsigned char i;
	checksum = 0;
	for (i = 0; i < rx_buf[2] + 3; i++)
		checksum ^= rx_buf[i];
	if(checksum==rx_buf[rx_wr_index-1])	  
			return  1;
	else 	return  0;
}

unsigned char Qrobot_interface::sumCheckSteer() {
	unsigned char i;
	checksum = 0;
	for (i = 0; i < rx_buf[3]; i++)
		checksum = checksum+rx_buf[i+2];
        checksum=~checksum;
        
	if(checksum==rx_buf[rx_wr_index-1])	  
			return  1;
	else 	return  0;
}
extern u8 USART3_FLAG;        
void uart3WriteBuf(uint8_t *buf, uint8_t len)
{
	while (len--) {
                while ((USART3->SR & 0x40) == 0);//等待TXE为1，发送寄存器为空TXE是由硬件设置的，它表明：数据已经从TDR中转移到移位寄存器了，数据发送已经开始；TDR寄存器是空的；下一个数据可以写入USART_DR寄存器，而不会覆盖前面的数据。
		USART_SendData(USART3,*buf++);                
                while(USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);//当一个帧发送完成时（结束位之后），TC位被置1当一帧发送完成时(停止位发送后)并且设置了TXE位，TC位被置起，如果USART_CR1寄存器中的TCIE位被置起时，则会产生中断
	}
}