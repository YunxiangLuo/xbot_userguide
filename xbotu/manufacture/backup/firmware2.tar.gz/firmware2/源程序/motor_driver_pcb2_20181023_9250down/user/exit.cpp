#include "motor.h"
#include "exti.h"
void exitConfiguration()
{
//	GPIO_InitTypeDef gpio_initstructure;
//	EXTI_InitTypeDef exti_initstructure;
//	
//    /*  PC0*/
//        gpio_initstructure.GPIO_Pin = GPIO_Pin_0;
//	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU; //??????
//	GPIO_Init(GPIOC, &gpio_initstructure);
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource0);
//	EXTI_ClearITPendingBit(EXTI_Line0);
//	exti_initstructure.EXTI_Line = EXTI_Line0;
//	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
//	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising;
//	exti_initstructure.EXTI_LineCmd = ENABLE;
//        EXTI_Init(&exti_initstructure);
}

