#ifndef __HAL_H__
#define __HAL_H__
	
#include "stm32f10x.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_it.h"

#include "motor.h"
#include "USART.h"
#include "steer.h"
#include "dmp.h"
#include "mpu9250_api.h"
#include "ioi2c.h"


//输出宏定义
#define LED3_ON		        GPIO_ResetBits(GPIOE, GPIO_Pin_3)
#define LED3_OFF		GPIO_SetBits(GPIOE, GPIO_Pin_3)

#define LED4_ON		        GPIO_ResetBits(GPIOE, GPIO_Pin_4)
#define LED4_OFF		GPIO_SetBits(GPIOE, GPIO_Pin_4)

#define LED5_ON		        GPIO_ResetBits(GPIOE, GPIO_Pin_5)
#define LED5_OFF		GPIO_SetBits(GPIOE, GPIO_Pin_5)

#define LED6_ON		        GPIO_ResetBits(GPIOE, GPIO_Pin_6)
#define LED6_OFF		GPIO_SetBits(GPIOE, GPIO_Pin_6)

#define TX_ENABLE		GPIO_SetBits(GPIOE, GPIO_Pin_15)
#define TX_DISABLE		GPIO_ResetBits(GPIOE, GPIO_Pin_15)

#define RX_ENABLE	        GPIO_SetBits(GPIOE, GPIO_Pin_14)
#define RX_DISABLE  	        GPIO_ResetBits(GPIOE, GPIO_Pin_14)

#define AUD_SHDN_ON		GPIO_ResetBits(GPIOE, GPIO_Pin_8)
#define AUD_SHDN_OFF		GPIO_SetBits(GPIOE, GPIO_Pin_8)

#define AUD_MUTE_ON		GPIO_SetBits(GPIOE, GPIO_Pin_9)
#define AUD_MUTE_OFF		GPIO_ResetBits(GPIOE, GPIO_Pin_9)


void ledFlash(void);
void ledBattery(void);
void ledImu(void);

void delayUs(u32 n);
void delayMs(u32 n);
//硬件初始化
void  chipHalInit(void);
void  chipOutHalInit(void);

//各个内部硬件模块的配置函数
extern void gpioConfiguration(void);			//GPIO
extern void rccConfiguration(void);			//RCC
extern void usartConfiguration(void);			//串口
extern void nvicConfiguration(void);			//NVIC
extern void exitConfiguration(void);			//NVIC
extern void timerConfiguration(void);
extern void sysTickInit(void);
extern void adcDmaInit(void);

extern uint16_t adc_convertedvalut[11];
extern Com1 usart1_com;
extern Com2 usart2_com;
extern Com3 usart3_com;
extern Com4 usart4_com;
extern steer steer_hor,steer_ver;

extern int dmp_read_fifo(short *gyro, short *accel, long *quat,
    unsigned long *timestamp, short *sensors, unsigned char *more);
#endif


