# xbot_driver

这是机器人纯c++驱动程序，除了使用了ros的ecl库程序，没有任何与ROS相关的程序。
