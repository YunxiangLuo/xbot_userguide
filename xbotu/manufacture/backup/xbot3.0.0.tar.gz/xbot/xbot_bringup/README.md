# xbot_bringup

这是机器人大部分程序启动的入口ROS包，可以启动xbot本体，rplidar激光雷达，realsense以及整体xbot-u的程序。
