#include "motor.h"
#include "exti.h"
void exitConfiguration()
{
	GPIO_InitTypeDef gpio_initstructure;
	EXTI_InitTypeDef exti_initstructure;
	
	/*  PD0*/
	gpio_initstructure.GPIO_Pin = GPIO_Pin_0;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOD, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource0);
	EXTI_ClearITPendingBit(EXTI_Line0);
	exti_initstructure.EXTI_Line = EXTI_Line0;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);
	
	/*  PD1*/
	gpio_initstructure.GPIO_Pin = GPIO_Pin_1;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOD, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource1);
	EXTI_ClearITPendingBit(EXTI_Line1);
	exti_initstructure.EXTI_Line = EXTI_Line1;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);
	
	/*  PD2*/
	gpio_initstructure.GPIO_Pin = GPIO_Pin_2;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOD, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource2);
	EXTI_ClearITPendingBit(EXTI_Line2);
	exti_initstructure.EXTI_Line = EXTI_Line2;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);
	
	/* PD3 */
	gpio_initstructure.GPIO_Pin = GPIO_Pin_3;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOD, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource3);
	EXTI_ClearITPendingBit(EXTI_Line3);
	exti_initstructure.EXTI_Line = EXTI_Line3;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);
	
	/* PD4 */
	gpio_initstructure.GPIO_Pin = GPIO_Pin_4;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOD, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource4);
	EXTI_ClearITPendingBit(EXTI_Line4);
	exti_initstructure.EXTI_Line = EXTI_Line4;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);
	
	/*  PD5 */
	gpio_initstructure.GPIO_Pin = GPIO_Pin_5;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOD, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource5);
	EXTI_ClearITPendingBit(EXTI_Line5);
	exti_initstructure.EXTI_Line = EXTI_Line5;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);
	
	/*  PD6*/
	gpio_initstructure.GPIO_Pin = GPIO_Pin_6;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOD, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource6);
	EXTI_ClearITPendingBit(EXTI_Line6);
	exti_initstructure.EXTI_Line = EXTI_Line6;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);
	
	/*  PD7 */
	gpio_initstructure.GPIO_Pin = GPIO_Pin_7;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOD, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD, GPIO_PinSource7);
	EXTI_ClearITPendingBit(EXTI_Line7);
	exti_initstructure.EXTI_Line = EXTI_Line7;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);
	
	/*  PC11 */
	gpio_initstructure.GPIO_Pin = GPIO_Pin_11;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource11);
	EXTI_ClearITPendingBit(EXTI_Line11);
	exti_initstructure.EXTI_Line = EXTI_Line11;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);	
	
	/*  PC12 */
	gpio_initstructure.GPIO_Pin = GPIO_Pin_12;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPU;
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &gpio_initstructure);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource12);
	EXTI_ClearITPendingBit(EXTI_Line12);
	exti_initstructure.EXTI_Line = EXTI_Line12;
	exti_initstructure.EXTI_Mode = EXTI_Mode_Interrupt;
	exti_initstructure.EXTI_Trigger = EXTI_Trigger_Rising;
	exti_initstructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&exti_initstructure);	
}

