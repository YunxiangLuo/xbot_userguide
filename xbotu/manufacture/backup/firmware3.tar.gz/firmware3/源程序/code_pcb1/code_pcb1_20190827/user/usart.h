#ifndef __USART_H__
#define __USART_H__

#include "stm32f10x.h"

#define UART1_RXSIZE		256
#define UART1_TXSIZE		256
#define UART2_RXSIZE		256
#define UART2_TXSIZE		256
#define UART3_RXSIZE		256
#define UART3_TXSIZE		256
#define RX1_BUF_SIZE        256
#define RX2_BUF_SIZE        256
#define RX3_BUF_SIZE        256

u8   usart1GetByte(u8* pChar);
u8   usart2GetByte(u8* pChar);
u8   usart3GetByte(u8* pChar);
void USART_DMA_Enable(DMA_Channel_TypeDef* DMA_CHx, u32 cmar, u16 cndtr);


class Qrobot_interface{
public:
	Qrobot_interface();
	~Qrobot_interface();
	
	unsigned char rx_buf[256];
	unsigned char tx_buf[256];
	unsigned char tmp_buf[256];
	unsigned char head_flag;
	unsigned char rx_gll_flag;
	
	u16 framelen,framelen_buf;
	  
	  
	  
	unsigned char sumCheck();
        unsigned char sumCheckBat();
	u8 decodeFrame(unsigned char adata);
	u8 decodeBatt(unsigned char adata);

protected:
	unsigned char rx_wr_index;
	unsigned char rx_wr_size;
	unsigned char checksum;
private:
};
class Com1: public Qrobot_interface{
public:
	Com1();
	~Com1();
	
	float tmp_float;
	short int tmp_int;
	
	u16 Voltage;
	u16 infr;
	u16 iValue;	
	u16 ultrasound;
	
	void data_deal();
private:
};

class Com2: public Qrobot_interface{
public:
	Com2();
	~Com2();	
	void data_deal();
private:
};

class Com3: public Qrobot_interface{
public:
	Com3();
	~Com3();	
	void data_deal();
private:
};

#endif
