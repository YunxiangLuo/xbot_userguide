#ifndef __TIME_H__
#define __TIME_H__
#include "stm32f10x.h"
#include "stm32f10x_tim.h"

#define SP              2000
#define my_pwm          0;//(SP / 2)

#endif
