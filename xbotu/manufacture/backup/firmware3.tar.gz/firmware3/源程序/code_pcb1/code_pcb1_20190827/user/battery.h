#ifndef __BATTERY_H__
#define __BATTERY_H__

#include "stm32f10x.h"
#include <math.h>

typedef struct {
  u16 chargeivalue;
  u8 rsoc; 
  u16 volate;
  u16 power_reserve;
  u16 power_stand;
  u16 use_cnt;
} Battery;


#endif



