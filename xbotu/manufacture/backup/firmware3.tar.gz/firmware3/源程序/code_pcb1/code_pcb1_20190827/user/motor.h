#ifndef __MOTOR_H__
#define __MOTOR_H__

#include "stm32f10x.h"
#include <math.h>
#define ABS(x) ((x)>=0?(x):(-x))	
#define ENCODER_FULL    20000
#define half_cycle      (ENCODER_FULL/2)
#define dt              0.1
#define pi              3.1415926535897932
 
#define MAX_target		55


#define U1_L_OFF		GPIO_SetBits(GPIOE, GPIO_Pin_8)
#define U1_L_ON		GPIO_ResetBits(GPIOE, GPIO_Pin_8)

#define V1_L_OFF			GPIO_SetBits(GPIOE, GPIO_Pin_7)
#define V1_L_ON		GPIO_ResetBits(GPIOE, GPIO_Pin_7)

#define W1_L_OFF			GPIO_SetBits(GPIOB, GPIO_Pin_1)
#define W1_L_ON		GPIO_ResetBits(GPIOB, GPIO_Pin_1)

#define U2_L_OFF			GPIO_SetBits(GPIOD, GPIO_Pin_15)
#define U2_L_ON		GPIO_ResetBits(GPIOD, GPIO_Pin_15)

#define V2_L_OFF		GPIO_SetBits(GPIOD, GPIO_Pin_14)
#define V2_L_ON		GPIO_ResetBits(GPIOD, GPIO_Pin_14)

#define W2_L_OFF			GPIO_SetBits(GPIOD, GPIO_Pin_13)
#define W2_L_ON		GPIO_ResetBits(GPIOD, GPIO_Pin_13)

/******** Motor Timer Pin Define ********/
#define U1_H_PWM TIM1->CCR3
#define V1_H_PWM TIM1->CCR2
#define W1_H_PWM TIM1->CCR1

#define U2_H_PWM TIM3->CCR3
#define V2_H_PWM TIM3->CCR2
#define W2_H_PWM TIM3->CCR1

typedef struct {
  float p, i, d;
} MotorPid;

typedef enum {
  STOP=0,
  POS_STATE,                                //正转
  NEG_STATE,
  RUN
} MotorState;

class QRobotControl	{
public:
	QRobotControl();
	~QRobotControl();
	
	int controllaw;
	int ControlLaw_Pre;
        float iValue;
	
	
	u8 location_flag;
	
	s16  max_controllaw;
	s16 max_isum;
	int distance,location;
	u8 hall;
	u8 hall_pre;
	u8 stop_cnt;
        u8 stop_cnt1;
	float target;
    u16 angle_now;
	u16 angle_now_tmp;
	u16 angle_pre;
	float angle_error;
    float angle_error_pre;
	s16 angle_delta,Angle_Delta_Pre;
	MotorPid pid,pid1,pid2,pid3,pid4;
	MotorPid pidsum,pidsum1,pidsum2,pidsum3,pidsum4;
	MotorState state;
	void Speed_control();
	void scale_adjust(s16* data);
protected: 
	void restrict_params(int* para, int Threshold);
  	void restrict_params(float* para, float Threshold);
    
};

class Motor1: public QRobotControl{
public:
  	Motor1();
	~Motor1();
    void read_hall_state();
    void judge_hall();
    void act_controllaw();
private:
};
class Motor2: public QRobotControl{
public:
  	Motor2();
	~Motor2();
    void read_hall_state();
    void judge_hall();
    void act_controllaw();
private:
};
class Motor3: public QRobotControl{
public:
	Motor3();
	~Motor3();
	void location_control();
    void read_hall_state();
    void judge_hall();
    void act_controllaw();
	u8 judge_direction();
	void motor_angle_count();
private:
};

#endif



