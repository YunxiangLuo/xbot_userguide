#include "stm32f10x.h"
#include "system_stm32f10x.h"

void rccConfiguration(void)
{
	SystemInit();//源自system_stm32f10x.c文件,只需要调用此函数,则可完成RCC的配置.具体请看2_RCC
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);	//复用功能允许，
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|
												 RCC_APB2Periph_GPIOC |RCC_APB2Periph_GPIOD| 
													 RCC_APB2Periph_GPIOE, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3 |RCC_APB1Periph_TIM4| RCC_APB1Periph_USART2 | RCC_APB1Periph_USART3 | RCC_APB1Periph_UART4, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1|RCC_APB2Periph_TIM1 | RCC_APB2Periph_ADC1, ENABLE);	
}

void sysTickInit(void)
{
	/* SystemFrequency / 1000    1ms
	* SystemFrequency / 100000	 10us
	* SystemFrequency / 1000000 1us
	*/
	
	//    SysTick->LOAD = SystemCoreClock / 100000;         // TICK
	//    SysTick->VAL = 0;
	//    SysTick->CTRL = 0x00000007; 
	if (SysTick_Config(SystemCoreClock / 100000))
	{ 
		/* Capture error */ 
		while (1);
	}
}

