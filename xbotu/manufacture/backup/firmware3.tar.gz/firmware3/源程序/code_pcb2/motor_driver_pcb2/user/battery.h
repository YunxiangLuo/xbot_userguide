#ifndef __BATTERY_H__
#define __BATTERY_H__

#include "stm32f10x.h"
#include <math.h>

typedef struct {
  u16 chargeivalue;
  u8 rsoc; 
  u16 volate;
} Battery;


#endif



