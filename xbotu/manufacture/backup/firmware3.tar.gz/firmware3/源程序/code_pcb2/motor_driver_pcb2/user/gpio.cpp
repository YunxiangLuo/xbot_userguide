#include "GPIO.h"
/*******************************************************************************
* Function Name  : gpioConfiguration
* 设置PD3,PD4,PD5,PD6为键盘输入
* 设置PB0,5,8,9; PC5,7; PD7 ;PA8 为输出LED灯
*******************************************************************************/
void gpioConfiguration(void)
{
	GPIO_InitTypeDef gpio_initstructure;
	
	gpio_initstructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;	//50M时钟速度
	GPIO_Init(GPIOA, &gpio_initstructure);         
	GPIO_SetBits(GPIOA, GPIO_Pin_11);
        GPIO_ResetBits(GPIOA,GPIO_Pin_8);
        
	gpio_initstructure.GPIO_Pin = GPIO_Pin_1 |GPIO_Pin_8 |GPIO_Pin_9;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;	//50M时钟速度
	GPIO_Init(GPIOB, &gpio_initstructure); 
	GPIO_ResetBits(GPIOB,GPIO_Pin_1 |GPIO_Pin_8 |GPIO_Pin_9 );

	gpio_initstructure.GPIO_Pin =  GPIO_Pin_10 | GPIO_Pin_11;
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_Out_OD;	       // ¿ªÂ©¸´ÓÃ¹¦ÄÜ
	GPIO_Init(GPIOB, &gpio_initstructure);	
        
        
	gpio_initstructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_12| GPIO_Pin_13| GPIO_Pin_14 | GPIO_Pin_15;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPD;	
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;	//50M时钟速度
	GPIO_Init(GPIOB, &gpio_initstructure);	

	gpio_initstructure.GPIO_Pin = GPIO_Pin_9;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;	//50M时钟速度
	GPIO_Init(GPIOC, &gpio_initstructure);         
	GPIO_ResetBits(GPIOC,GPIO_Pin_9);
	
	gpio_initstructure.GPIO_Pin =   GPIO_Pin_11 | GPIO_Pin_12;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_IPD;	
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;	//50M时钟速度
	GPIO_Init(GPIOD, &gpio_initstructure);	
        
	gpio_initstructure.GPIO_Pin = GPIO_Pin_10 |GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;	//50M时钟速度
	GPIO_Init(GPIOD, &gpio_initstructure);  
	GPIO_SetBits(GPIOD,GPIO_Pin_10 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15 );        
	
	gpio_initstructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 |GPIO_Pin_5 |GPIO_Pin_6| GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_12|GPIO_Pin_14|GPIO_Pin_15;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;	//50M时钟速度
	GPIO_Init(GPIOE, &gpio_initstructure);  
	GPIO_ResetBits(GPIOE,GPIO_Pin_0|GPIO_Pin_1|  GPIO_Pin_7|GPIO_Pin_9); 
        GPIO_SetBits(GPIOE,GPIO_Pin_2 | GPIO_Pin_12|GPIO_Pin_3 | GPIO_Pin_4 |GPIO_Pin_5 |GPIO_Pin_6|GPIO_Pin_8); 
}


