/************************************************************
**实验名称:baofeng
**功能:motor driver
**注意事项:
**作者:BOBO
*************************************************************/
#include <string.h>
#include "hal.h"	

/*************test**************/
#include "stdio.h"
#include "stm32f10x_usart.h"
/*************test**************/

u16 time_10us_count=0;
u16 time_1ms_count=0;
u8  time_1ms_flag,time_1ms_cnt;
u8 voice_state;
u8 USART3_FLAG;
u16 trig_cnt=0;
extern u16 rx1buf[UART1_RXSIZE];
extern uint32_t micros(void);
void com1Cmd3();
void com1Cmd4();
void com1Cmd5();
void com1Cmd6();
void ultCapture(void);
float test11;
u8 send_contro;
u8 errorstate;
u8 i2c_buf[100];
CaptureTypedef  ult0,ult1,ult2,ult3,ult4,ult5;

int main(void)
{
	u8 ch;
	u8 ch2;
	u8 initservo = 2;
	u32 test;
	uint16_t fifo_count = 0;
	delayMs(50);
	chipHalInit();			//片内硬件初始化
	chipOutHalInit();		//片外硬件初始化
	delayMs(50);

	
	steer_hor.id=1;  //水平
	steer_ver.id=2;  //tanjian mofidy
	
	AUD_SHDN_OFF;  // audio on 
	AUD_MUTE_OFF;  //mute
	
	TX_ENABLE;
	RX_DISABLE;
	LobotSerialServoMove(steer_hor.id, 500, 500);  //初始化舵机位置
	RX_ENABLE;
	TX_DISABLE;
	delayUs(500);
	
	
	TX_ENABLE;
	RX_DISABLE;
	LobotSerialServoMove(steer_ver.id, 500, 500);
	RX_ENABLE;
	TX_DISABLE; 
	delayUs(500);
	

	while(1)
	{             
		ultCapture();
		
		if( usart1GetByte(&ch) )//接收电脑指令
		{		 
			if( usart1_com.decodeFrame(ch) ) 
			{  
				//ledFlash();
				switch(usart1_com.rx_buf[3])
				{
				case 0x03:com1Cmd3();break;//水平舵机控制
				case 0x04:com1Cmd4();break;//竖直舵机控制
				case 0x05:com1Cmd5();break;//声音使能控制
				case 0x06:com1Cmd6();break;//状态灯控制
				default : break;
				}				
			}
		}
		
	  if(time_1ms_flag || initservo > 0)  //发送一个传感器读相关指令
		{
			send_contro++;
			
			if(initservo != 0)
				initservo--;
						
			TX_ENABLE;
			RX_DISABLE;			                          
			if(send_contro%2)
				LobotSerialServoReadPosition(steer_hor.id);//水平舵机控制
			else
				LobotSerialServoReadPosition(steer_ver.id);//竖直舵机控制 
			
			RX_ENABLE;
			TX_DISABLE;
		}
		
//		if(initservo == 0)
//		{			
//			TX_ENABLE;
//			RX_DISABLE;	
//			LobotSerialServoReadPosition(steer_hor.id);//水平舵机控制
//			RX_ENABLE;
//			TX_DISABLE;
//			initservo++;
//		}
//		else if(initservo == 1)
//		{
//			TX_ENABLE;
//			RX_DISABLE;
//			LobotSerialServoReadPosition(steer_ver.id);//竖直舵机控制 
//			RX_ENABLE;
//			TX_DISABLE;
//			initservo++;
//		}else{
//			initservo = 2;
//		}	
		
		if( usart3GetByte(&ch2) )//接收水平舵机角度 无实时性要求
		{		 
			if( usart3_com.decodeSteer(ch2) ) 
			{
				if(usart3_com.rx_buf[2] == steer_hor.id)//水平舵机值      id 1
					steer_hor.angle_now=(u16)((usart3_com.rx_buf[6]<<8|usart3_com.rx_buf[5])*0.24);
				else if(usart3_com.rx_buf[2] == steer_ver.id)  
					steer_ver.angle_now=(u16)((usart3_com.rx_buf[6]<<8|usart3_com.rx_buf[5])*0.24);                         
			}
		}
		
		fifo_count = MPU9250_getFIFOCount();//读取FIFO计数
		
		if(fifo_count >= 0x0200)//如果FIFO值>0x0200，此时DMP的结果错误，直接复位FIFO
		{
			MPU9250_resetFIFO();
		}
		else
		{
			
			if(fifo_count >= 0x2a)//如果FIFO值 > 0x2a,此时DMP转换完成并且数值正常
			{	
                                readdmp(); //首先要读取DMP FIFO，读取之后才能进行计算姿态的操作
				getAcc_gyro();
				getmag();
				getquaternion();
				getyawpitchroll();//计算并且获取yaw、pitch、roll，结果保存在yprf[3]数组中
				MPU9250_resetFIFO();					
				
			}	
		}	                       
		
		if(time_1ms_flag)  //发送一个传感器读相关指令
		{
			time_1ms_flag=0;
//			send_contro++;
//			//ledFlash();   
//			
//			TX_ENABLE;
//			RX_DISABLE;			                          
//			if(send_contro%2)
//				LobotSerialServoReadPosition(steer_hor.id);//水平舵机控制
//			else
//				LobotSerialServoReadPosition(steer_ver.id);//竖直舵机控制 			
//			//delayUs(200) ;
//			RX_ENABLE;
//			TX_DISABLE;
			
			test=micros();
			
			memcpy(usart1_com.tx_buf+4,&steer_hor.angel_target,1);   //水平舵机角度
			memcpy(usart1_com.tx_buf+5,&steer_ver.angel_target,1);   //竖直舵机角度
			memcpy(usart1_com.tx_buf+6,&voice_state,1);   //音频状态
			memcpy(usart1_com.tx_buf+7,accelf,sizeof(accelf));   //accx/y/z
			memcpy(usart1_com.tx_buf+13,gyrof,sizeof(gyrof));   //gyrofx/y/z
			memcpy(usart1_com.tx_buf+19,mag,sizeof(mag));      //magx/y/z
			memcpy(usart1_com.tx_buf+25,yprf,sizeof(yprf));   //yaw/pitch/roll
			memcpy(usart1_com.tx_buf+37,q,sizeof(q));   //q
			
			usart1_com.tx_buf[53]= errorstate;
			
			usart1_com.tx_buf[54]=test; //time1 1us cnt
      usart1_com.tx_buf[55]=test>>8;
      usart1_com.tx_buf[56]=test>>16; //time1 1us cnt
      usart1_com.tx_buf[57]=test>>24;
			
			//old PCB2 code start
			//memcpy(usart1_com.tx_buf+3,&ult0.ech_data,2);//Front_left超声测距 0~65535/ 1us  ech0
			//memcpy(usart1_com.tx_buf+5,&ult1.ech_data,2);//Front_cent超声测距 0~65535/ 1us  ech1
			//memcpy(usart1_com.tx_buf+7,&ult2.ech_data,2);//Front_right超声测距 0~65535/ 1us ech2
			//memcpy(usart1_com.tx_buf+9,&ult3.ech_data,2);//Back_left超声测距 0~65535/ 1us  ech3
			
			//memcpy(usart1_com.tx_buf+11,adc_convertedvalut,2);//Front_left红外  RED_ADIN0
			//memcpy(usart1_com.tx_buf+13,adc_convertedvalut+1,2);//Front_cent红外  RED_ADIN1
			//memcpy(usart1_com.tx_buf+15,adc_convertedvalut+2,2);//Front_cent红外 RED_ADIN2
			//memcpy(usart1_com.tx_buf+17,adc_convertedvalut+3,2);//Back_left红外  RED_ADIN3        
			
			//memcpy(usart1_com.tx_buf+19,accelf,sizeof(accelf)); 
			//memcpy(usart1_com.tx_buf+25,gyrof,sizeof(gyrof)); 
			//memcpy(usart1_com.tx_buf+29,q,sizeof(q));
			//memcpy(usart1_com.tx_buf+47,yprf,sizeof(yprf));
			//old PCB2 code end
			
			
			//usart1_com.tx_buf[71]=errorstate;
			//memcpy(usart1_com.tx_buf+72,&test,sizeof(test)); 
			usart1_com.data_deal();
			USART_DMA_Enable(DMA1_Channel4, (u32)&usart1_com.tmp_buf,60);   
		}
	}
}

void com1Cmd3()
{
	// u16 t1=0;
	TX_ENABLE;
	RX_DISABLE;
	//     while(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_15)==0X00)//引脚未置低，程序在此等待,最多等待1us
	//     {
	//          t1++;
	//          if(t1 > 72)//1us
	//          {
	//           break;
	//          }
	//          else
	//          {
	//           ;
	//          }
	//     }     
	steer_hor.angel_target=usart1_com.rx_buf[4];
	if(steer_hor.angel_target<30)
		steer_hor.angel_target=30;    //tanjian add the min limit
	if(steer_hor.angel_target>210)
		steer_hor.angel_target=210;  
	steer_hor.angle_tmp=(int16_t)((steer_hor.angel_target)*4.166666666666667);   
	
	LobotSerialServoMove(steer_hor.id, steer_hor.angle_tmp, 500);  //舵机1用500ms转动到100位置
	
	RX_ENABLE;
	TX_DISABLE;   
}
void com1Cmd4()
{
	//u16 t1=0;
	TX_ENABLE;//E15
	RX_DISABLE;//E14
	//     while(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_15)==0X00)//引脚未置低，程序在此等待
	//     {
	//          t1++;
	//          if(t1 > 72)//1us
	//          {
	//           break;
	//          }
	//          else
	//          {
	//           ;
	//          }
	//     }
	steer_ver.angel_target=usart1_com.rx_buf[4];
	if(steer_ver.angel_target<60)
		steer_ver.angel_target=60;      //tanjian add the min limit
	if(steer_ver.angel_target>150)
		steer_ver.angel_target=150;      
	steer_ver.angle_tmp=(u16)((steer_ver.angel_target)*4.166666666666667);  
	
	
	
	LobotSerialServoMove(steer_ver.id, steer_ver.angle_tmp, 500);  //舵机1用500ms转动到100位置
	RX_ENABLE;
	TX_DISABLE;   
}

void com1Cmd5()
{
	voice_state=usart1_com.rx_buf[4];  //？？？
	if(voice_state)
		AUD_MUTE_ON;
	else 
		AUD_MUTE_OFF; 
}

u8 led_state;
void com1Cmd6()
{
	led_state=usart1_com.rx_buf[4];
	if(led_state & 0x01)
		LED3_ON;
	else
		LED3_OFF;
	
	if(led_state & 0x02)
		LED4_ON;
	else
		LED4_OFF;
	
	if(led_state & 0x04)
		LED5_ON;
	else
		LED5_OFF;   
	
	if(led_state & 0x08)
		LED6_ON;
	else
		LED6_OFF;     
}
u16 TT[8];   
u32 tt;
u8 ultraChanSelect;

void ultCapture(void)
{	
	if(trig_cnt>=5000)
	{
		trig_cnt=0;
		ultraChanSelect++;
		ultraChanSelect=ultraChanSelect%2;
	}
	if(trig_cnt<50) 
	{
		if(ultraChanSelect==ultra1_2)
		{
			GPIO_SetBits(GPIOE,GPIO_Pin_1);
			GPIO_SetBits(GPIOE,GPIO_Pin_0);
			GPIO_ResetBits(GPIOB,GPIO_Pin_9);
			GPIO_ResetBits(GPIOB,GPIO_Pin_8);
			ult0.ech_data=0;
			ult1.ech_data=0;
			ult2.ech_data=0;
			ult3.ech_data=0;
		}
		else if(ultraChanSelect==ultra3_4)
		{
			GPIO_ResetBits(GPIOE,GPIO_Pin_1);
			GPIO_ResetBits(GPIOE,GPIO_Pin_0);
			GPIO_SetBits(GPIOB,GPIO_Pin_9);
			GPIO_SetBits(GPIOB,GPIO_Pin_8);
			ult0.ech_data=0;
			ult1.ech_data=0;
			ult2.ech_data=0;
			ult3.ech_data=0;
		}
		else 
		{
			GPIO_ResetBits(GPIOE,GPIO_Pin_1);
			GPIO_ResetBits(GPIOE,GPIO_Pin_0);
			GPIO_ResetBits(GPIOB,GPIO_Pin_9);
			GPIO_ResetBits(GPIOB,GPIO_Pin_8);
		}
		
		
		ult0.ech_up_down=ult0.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12);
		if(ult0.ech_up_down==0x7f)//up 7f
		{
			ult0.ech_cnt=micros();
		}
		if(ult0.ech_up_down==0x80)//down
		{
			ult0.ech_data=micros()-ult0.ech_cnt;
		}        
		ult1.ech_up_down=ult1.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13);
		if(ult1.ech_up_down==0x7f)//up 7f
		{
			ult1.ech_cnt=micros();
		}
		if(ult1.ech_up_down==0x80)//down
		{
			ult1.ech_data=micros()-ult1.ech_cnt;
		}
		
		ult2.ech_up_down=ult2.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14);
		if(ult2.ech_up_down==0x7f)//up
		{
			ult2.ech_cnt=micros();
		}
		if(ult2.ech_up_down==0x80)//down
		{
			ult2.ech_data=micros()-ult2.ech_cnt;		
		}
		
		ult3.ech_up_down=ult3.ech_up_down<<1 | GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15);
		if(ult3.ech_up_down==0x7f)//up
		{
			ult3.ech_cnt=micros();
		}
		if(ult3.ech_up_down==0x80)//down
		{
			ult3.ech_data=micros()-ult3.ech_cnt;//(u16)(tt>>3);
		}
	}
}

#ifdef __cplusplus
extern "C" {
#endif 
	void SysTick_Handler()
	{  		
		time_1ms_cnt++;
		if(time_1ms_cnt>=100)
		{
			time_1ms_flag=1;
			time_1ms_cnt=0;
		}
	}
	
#ifdef __cplusplus
}
#endif
