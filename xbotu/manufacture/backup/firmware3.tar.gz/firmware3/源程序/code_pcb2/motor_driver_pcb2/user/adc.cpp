#include "adc.h"
/************************************************************
* PA0 -> RED_AIN3  PA1 -> RED_AIN4 PA4 -> RED_AIN5 PA5 -> RED_AIN6 PA6 -> RED_AIN7
* PC0 -> Volate_value PC1 -> RED_AIN0 PC2 -> RED_AIN1 PC3 -> RED_AIN2
*************************************************************/
uint16_t adc_convertedvalut[4];

void adcDmaInit()
{
    DMA_InitTypeDef dma_initstructure;
    ADC_InitTypeDef adc_initstructure;
    GPIO_InitTypeDef gpio_initstructure;

    /* Configure PIN as analog input */
    gpio_initstructure.GPIO_Pin = GPIO_Pin_3;
    gpio_initstructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOC, &gpio_initstructure);
	
    gpio_initstructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
    gpio_initstructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &gpio_initstructure);

    DMA_DeInit(DMA1_Channel1);
    dma_initstructure.DMA_PeripheralBaseAddr = ADC1_DR_ADDRESS;                 //自定义的一个地址变量，给DMA一个起始地址
    dma_initstructure.DMA_MemoryBaseAddr = (u32) &adc_convertedvalut;           //内存地址
    dma_initstructure.DMA_DIR = DMA_DIR_PeripheralSRC;                          //dma传输方向单向
    dma_initstructure.DMA_BufferSize = Sample_Num;                          //设置DMA在传输时缓冲区的长度word
    dma_initstructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;            //设置DMA的外设递增模式，1个外设ADC1
    dma_initstructure.DMA_MemoryInc = DMA_MemoryInc_Enable;                     //设置DMA的内存递增模式
    dma_initstructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord; //外设数据字长
    dma_initstructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;         //内存数据字长
    dma_initstructure.DMA_Mode = DMA_Mode_Circular;                             //设置DMA的传输模式，连续不断循环模式
    dma_initstructure.DMA_Priority = DMA_Priority_High;                         //设置DMA的优先级别
    dma_initstructure.DMA_M2M = DMA_M2M_Disable;                                //设置DMA的2个memory中的变量互相访问
    DMA_Init(DMA1_Channel1, &dma_initstructure);

    /* Enable DMA1 channel1 */
    DMA_Cmd(DMA1_Channel1, ENABLE); 

    /* ADC1 configuration ------------------------------------------------------*/
    adc_initstructure.ADC_Mode = ADC_Mode_Independent;                          //独立工作模式
    adc_initstructure.ADC_ScanConvMode = ENABLE;                                //扫描方式
    adc_initstructure.ADC_ContinuousConvMode = ENABLE;                          //连续转换
    adc_initstructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;         //外部触发禁止
    adc_initstructure.ADC_DataAlign = ADC_DataAlign_Right;                      //数据右对齐
    adc_initstructure.ADC_NbrOfChannel = 4;                                     //用于转换的通道数
    ADC_Init(ADC1, &adc_initstructure);

    /*配置ADC时钟为PCLK2的8分频，即9HZ*/
    RCC_ADCCLKConfig(RCC_PCLK2_Div8);
    /* ADC1 regular channels configuration */
    ADC_RegularChannelConfig(ADC1, ADC_Channel_13, 1, ADC_SampleTime_239Cycles5);//valateValue	
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 2, ADC_SampleTime_239Cycles5);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 3, ADC_SampleTime_239Cycles5);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 4, ADC_SampleTime_239Cycles5);
    
    /* Enable ADC1 DMA [使能ADC1 DMA]*/
    ADC_DMACmd(ADC1, ENABLE);

    /* Enable ADC1 [使能ADC1]*/
    ADC_Cmd(ADC1, ENABLE);

    /* Enable ADC1 reset calibaration register */
    ADC_ResetCalibration(ADC1);
    /* Check the end of ADC1 reset calibration register */
    while (ADC_GetResetCalibrationStatus(ADC1));

    /* Start ADC1 calibaration */
    ADC_StartCalibration(ADC1);
    /* Check the end of ADC1 calibration */
    while (ADC_GetCalibrationStatus(ADC1));

    /* Start ADC1 Software Conversion */
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}

