#include <battery.h>
Battery battery1,battery2;

