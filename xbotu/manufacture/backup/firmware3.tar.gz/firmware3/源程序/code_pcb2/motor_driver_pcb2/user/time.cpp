#include "time.h"

void timerConfiguration()
{
	TIM_TimeBaseInitTypeDef timeTimeBaseStructure;
	GPIO_InitTypeDef gpio_initstructure;
	TIM_OCInitTypeDef timOcInitStructure;
	
	//TIM_BDTRInitTypeDef TIM_BDTRInitStructure;
	
	/*************TIME1 AS PWM***********************/
	GPIO_PinRemapConfig(GPIO_FullRemap_TIM1, ENABLE);
	
//	gpio_initstructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_11 | GPIO_Pin_13;
//	gpio_initstructure.GPIO_Mode = GPIO_Mode_AF_PP;		    // 复用推挽输出
//	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(GPIOE, &gpio_initstructure);
//	
//	/* Time base configuration */
//	timeTimeBaseStructure.TIM_Period = SP;      //����ʱ����0������9999����Ϊ10000�Σ�Ϊһ����ʱ����
//	timeTimeBaseStructure.TIM_Prescaler = 0;	    //����Ԥ��Ƶ����Ԥ��Ƶ����Ϊ72MHz
//	timeTimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;	//����ʱ�ӷ�Ƶϵ��������Ƶ
//	timeTimeBaseStructure.TIM_CounterMode = TIM_CounterMode_CenterAligned1;  //���ϼ���ģʽ
//
//	TIM_TimeBaseInit(TIM1, &timeTimeBaseStructure);
//
//	/* PWM1 Mode configuration: Channel1 */
//	timOcInitStructure.TIM_OCMode = TIM_OCMode_PWM1;	    //����ΪPWMģʽ1
//	timOcInitStructure.TIM_OutputState = TIM_OutputState_Enable;
//	timOcInitStructure.TIM_Pulse = my_pwm;	   //��������ֵ�������������������ֵʱ����ƽ��������
//	timOcInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low; //����ʱ������ֵС��CCR1_ValʱΪ�ߵ�ƽ
//
//	TIM_OC1Init(TIM1, &timOcInitStructure);	 //ʹ��ͨ��1
//	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
//
//	TIM_OC2Init(TIM1, &timOcInitStructure);	  //ʹ��ͨ��2
//	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
//
//	TIM_OC3Init(TIM1, &timOcInitStructure);	 //ʹ��ͨ��3
//	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
//
//	TIM_ARRPreloadConfig(TIM1, ENABLE);	 // ʹ��TIM1���ؼĴ���ARR
//
//	/* TIM1 enable counter */
//	TIM_Cmd(TIM1, ENABLE);          //ʹ�ܶ�ʱ��1
//	TIM_CtrlPWMOutputs(TIM1, ENABLE);
	
/*********************************************************************/
	/* TIM2 enable counter */
//	TIM_Cmd(TIM2, ENABLE);          //ʹ�ܶ�ʱ��1
//	TIM_CtrlPWMOutputs(TIM2, ENABLE);

//	timeTimeBaseStructure.TIM_Period = 0xffff;     //1us
//	timeTimeBaseStructure.TIM_Prescaler = 72;	 //1M 的时�? 
//	timeTimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;	
//	timeTimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	
//	TIM_TimeBaseInit(TIM2, &timeTimeBaseStructure);
	
//	TIM_ARRPreloadConfig(TIM2, ENABLE);		
/*************TIME3 AS PWM***********************/
	/* TIM3 clock enable */
	GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);

	/*GPIOC Configuration: TIM3 channel 3 and 2 and 4 as alternate function push-pull */
	gpio_initstructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8;
	gpio_initstructure.GPIO_Mode = GPIO_Mode_AF_PP;		    // 复用推挽输出
	gpio_initstructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &gpio_initstructure);	
	
	/* Time base configuration */
	timeTimeBaseStructure.TIM_Period = SP;       
	timeTimeBaseStructure.TIM_Prescaler = 0;	   
	timeTimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;	
	timeTimeBaseStructure.TIM_CounterMode = TIM_CounterMode_CenterAligned1;  

	TIM_TimeBaseInit(TIM3, &timeTimeBaseStructure);

	/* PWM1 Mode configuration: Channel1 */
	timOcInitStructure.TIM_OCMode = TIM_OCMode_PWM1;	    
	timOcInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	timOcInitStructure.TIM_Pulse = my_pwm;	  
	timOcInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low; 

	TIM_OC1Init(TIM3, &timOcInitStructure);
	TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);	  

	TIM_OC2Init(TIM3, &timOcInitStructure);
	TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);	

	TIM_OC3Init(TIM3, &timOcInitStructure);
	TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);

	TIM_ARRPreloadConfig(TIM3, ENABLE);			

	/* TIM3 enable counter */
	TIM_Cmd(TIM3, ENABLE);                  
	TIM_CtrlPWMOutputs(TIM3, DISABLE);	
	
  /* TIM2 + TIM4 configuration*/ 
  /* Time Base configuration */
	
	TIM_TimeBaseStructInit(&timeTimeBaseStructure); 
  timeTimeBaseStructure.TIM_Period = 0xffff;        
  timeTimeBaseStructure.TIM_Prescaler = 0x0;       
  timeTimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;    
  timeTimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
  TIM_TimeBaseInit(TIM2, &timeTimeBaseStructure); 

  TIM_PrescalerConfig(TIM2, 0, TIM_PSCReloadMode_Update);
  /* Disable the TIM2 Update event */
  TIM_UpdateDisableConfig(TIM2, ENABLE);
  /* ----------------------TIM2 Configuration as slave for the TIM4 ----------*/
  /* Select the TIM2 Input Trigger: TIM4 TRGO used as Input Trigger for TIM2*/
  TIM_SelectInputTrigger(TIM2, TIM_TS_ITR2);
  /* Use the External Clock as TIM2 Slave Mode */
  TIM_SelectSlaveMode(TIM2, TIM_SlaveMode_External1);
  /* Enable the TIM2 Master Slave Mode */
  TIM_SelectMasterSlaveMode(TIM2, TIM_MasterSlaveMode_Enable);
  TIM_ARRPreloadConfig(TIM2, ENABLE);	

  timeTimeBaseStructure.TIM_Period = 0xffff;     //1us
  timeTimeBaseStructure.TIM_Prescaler = 72;	 //1M 
  timeTimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;	
  timeTimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
  TIM_TimeBaseInit(TIM4, &timeTimeBaseStructure);
  TIM_ARRPreloadConfig(TIM4, ENABLE);	

  TIM_SelectSlaveMode(TIM4, TIM_SlaveMode_Reset);
  TIM_UpdateRequestConfig(TIM4, TIM_UpdateSource_Regular);
  /* ----------------------TIM4 Configuration as Master for the TIM2 -----------*/
  /* Use the TIM4 Update event  as TIM4 Trigger Output(TRGO) */
  TIM_SelectOutputTrigger(TIM4, TIM_TRGOSource_Update);
  /* Enable the TIM3 Master Slave Mode */
  TIM_SelectMasterSlaveMode(TIM4, TIM_MasterSlaveMode_Enable);

  TIM_Cmd(TIM4, ENABLE); 
  TIM_Cmd(TIM2, ENABLE); 
	
}

uint32_t micros(void)
{
 	uint32_t temp=0 ;
  temp = TIM2->CNT;
 	temp= (temp << 16) + TIM4->CNT;
 	return temp;
}