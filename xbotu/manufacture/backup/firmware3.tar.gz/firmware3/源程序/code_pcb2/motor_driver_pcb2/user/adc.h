#ifndef _QROBOT_ADC_H_
#define _QROBOT_ADC_H_

#include "stm32f10x.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_dma.h"

#define ADC1_DR_ADDRESS         ((u32)0x40012400+0x4c)
#define Sample_Num              4
void adcConfiguartion(void);

#endif  /* _QROBOT_ADC_H_ */
