
Some scripts we use on our file server to help serve firmware and windows downloads.

