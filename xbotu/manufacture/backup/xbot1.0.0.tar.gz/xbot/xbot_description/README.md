# xbot Description

 This package contains xbot urdf files and gazebo model.

To view xbot robot model in RViz, type

```roslaunch xbot_description display.launch```

To view xbot in Gazebo, type

```roslaunch xbot_description gazebo.launch```
